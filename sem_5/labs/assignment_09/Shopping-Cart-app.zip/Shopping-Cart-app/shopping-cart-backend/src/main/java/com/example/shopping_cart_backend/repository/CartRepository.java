package com.example.shopping_cart_backend.repository;

import com.example.shopping_cart_backend.model.Cart;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CartRepository
        extends MongoRepository<Cart, String> {
}