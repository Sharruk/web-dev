package com.example.shopping_cart_backend.repository;

import com.example.shopping_cart_backend.model.Product;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductRepository
        extends MongoRepository<Product, String> {
}