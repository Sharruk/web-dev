package com.example.shopping_cart_backend.controller;

import com.example.shopping_cart_backend.model.Cart;
import com.example.shopping_cart_backend.model.CartItem;
import com.example.shopping_cart_backend.repository.CartRepository;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin(origins = "http://localhost:5173")
public class CartController {

    private final CartRepository cartRepository;

    public CartController(CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }

    @GetMapping
    public Cart getCart() {
        return cartRepository.findAll()
                .stream()
                .findFirst()
                .orElseGet(() -> cartRepository.save(new Cart()));
    }

    @PostMapping("/add")
    public Cart addToCart(@RequestBody CartItem newItem) {

        Cart cart = getCart();

        boolean productExists = false;

        for (CartItem item : cart.getItems()) {

            if (item.getProductId().equals(newItem.getProductId())) {
                item.setQuantity(
                        item.getQuantity() + newItem.getQuantity()
                );

                productExists = true;
                break;
            }
        }

        if (!productExists) {
            cart.getItems().add(newItem);
        }

        return cartRepository.save(cart);
    }

    @PutMapping("/update/{productId}/{quantity}")
    public Cart updateQuantity(
            @PathVariable String productId,
            @PathVariable int quantity
    ) {

        Cart cart = getCart();

        for (CartItem item : cart.getItems()) {

            if (item.getProductId().equals(productId)) {
                item.setQuantity(quantity);
                break;
            }
        }

        return cartRepository.save(cart);
    }

    @DeleteMapping("/remove/{productId}")
    public Cart removeFromCart(
            @PathVariable String productId
    ) {

        Cart cart = getCart();

        cart.getItems().removeIf(
                item -> item.getProductId().equals(productId)
        );

        return cartRepository.save(cart);
    }
}