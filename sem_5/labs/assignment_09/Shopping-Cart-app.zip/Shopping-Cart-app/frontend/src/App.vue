<template>
  <div class="app">
    <h1>Shopping Cart Application</h1>

    <div class="buttons">
      <button @click="currentPage = 'products'">
        Products
      </button>

      <button @click="currentPage = 'cart'">
        Cart ({{ cart.length }})
      </button>
    </div>

    <ProductList
      v-if="currentPage === 'products'"
      @add-to-cart="addToCart"
    />

    <Cart
      v-else
      :cart="cart"
      @increase="increaseQuantity"
      @decrease="decreaseQuantity"
      @remove="removeItem"
    />
  </div>
</template>

<script>
import ProductList from './components/ProductList.vue'
import Cart from './components/Cart.vue'
import api from './services/api'

export default {
  components: {
    ProductList,
    Cart
  },

  data() {
    return {
      currentPage: 'products',
      cart: []
    }
  },

  mounted() {
    this.loadCart()
  },

  methods: {
    async loadCart() {
      try {
        const response = await api.get('/cart')
        this.cart = response.data.items
      } catch (error) {
        console.log('Error loading cart:', error)
      }
    },

    async addToCart(product) {
      try {
        const item = {
          productId: product.id,
          productName: product.name,
          price: product.price,
          quantity: 1
        }

        const response = await api.post('/cart/add', item)

        this.cart = response.data.items
      } catch (error) {
        console.log('Error adding product:', error)
      }
    },

    async increaseQuantity(id) {
      const item = this.cart.find(
        product => product.productId === id
      )

      if (item) {
        const newQuantity = item.quantity + 1

        const response = await api.put(
          `/cart/update/${id}/${newQuantity}`
        )

        this.cart = response.data.items
      }
    },

    async decreaseQuantity(id) {
      const item = this.cart.find(
        product => product.productId === id
      )

      if (item && item.quantity > 1) {
        const newQuantity = item.quantity - 1

        const response = await api.put(
          `/cart/update/${id}/${newQuantity}`
        )

        this.cart = response.data.items
      }
    },

    async removeItem(id) {
      try {
        const response = await api.delete(
          `/cart/remove/${id}`
        )

        this.cart = response.data.items
      } catch (error) {
        console.log('Error removing product:', error)
      }
    }
  }
}
</script>

<style>
body {
  margin: 0;
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
}

.app {
  width: 80%;
  margin: 30px auto;
  text-align: center;
}

h1 {
  color: #333;
}

.buttons {
  margin: 20px;
}

button {
  padding: 10px 18px;
  margin: 5px;
  border: none;
  border-radius: 5px;
  background-color: #007bff;
  color: white;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}
</style>