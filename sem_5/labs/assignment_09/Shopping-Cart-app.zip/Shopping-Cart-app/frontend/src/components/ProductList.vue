<template>
  <div>
    <h2>Available Products</h2>

    <div class="products">
      <div
        class="product"
        v-for="product in products"
        :key="product.id"
      >
        <h3>{{ product.name }}</h3>

        <p>Price: ₹{{ product.price }}</p>

        <button @click="$emit('add-to-cart', product)">
          Add to Cart
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import api from '../services/api'

export default {
  data() {
    return {
      products: []
    }
  },

  mounted() {
    this.loadProducts()
  },

  methods: {
    async loadProducts() {
      try {
        const response = await api.get('/products')
        this.products = response.data
      } catch (error) {
        console.log('Error loading products:', error)
      }
    }
  }
}
</script>

<style scoped>
.products {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 20px;
}

.product {
  width: 200px;
  padding: 20px;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 0 8px #ccc;
}

.product h3 {
  color: #333;
}

.product p {
  font-size: 18px;
}
</style>