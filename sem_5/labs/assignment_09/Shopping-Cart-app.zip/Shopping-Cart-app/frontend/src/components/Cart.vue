<template>
  <div>
    <h2>Shopping Cart</h2>

    <p v-if="cart.length === 0">
      Your cart is empty.
    </p>

    <div
      class="cart-item"
      v-for="item in cart"
      :key="item.productId"
    >
      <h3>{{ item.productName }}</h3>

      <p>Price: ₹{{ item.price }}</p>

      <p>Quantity: {{ item.quantity }}</p>

      <button @click="$emit('increase', item.productId)">
        +
      </button>

      <button @click="$emit('decrease', item.productId)">
        -
      </button>

      <button @click="$emit('remove', item.productId)">
        Remove
      </button>

      <p>
        Subtotal:
        ₹{{ item.price * item.quantity }}
      </p>
    </div>

    <h2 v-if="cart.length > 0" class="total">
      Total Amount: ₹{{ totalAmount }}
    </h2>
  </div>
</template>

<script>
export default {
  props: {
    cart: {
      type: Array,
      required: true
    }
  },

  computed: {
    totalAmount() {
      return this.cart.reduce(
        (total, item) =>
          total + item.price * item.quantity,
        0
      )
    }
  }
}
</script>

<style scoped>
.cart-item {
  width: 350px;
  margin: 20px auto;
  padding: 20px;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 0 8px #ccc;
}

.cart-item button {
  margin: 5px;
}

.total {
  color: #222;
  background-color: white;
  padding: 20px;
  margin-top: 25px;
  border-radius: 10px;
  font-size: 26px;
  font-weight: bold;
}
</style>