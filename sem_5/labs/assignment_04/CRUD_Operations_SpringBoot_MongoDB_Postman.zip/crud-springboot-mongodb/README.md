# CRUD Operations using Spring Boot, MongoDB and Postman
### ICS1511 – Web Application Development Lab – Exercise 4
Sharruk S | 3122247001061 | III Year / V Sem | Batch 2024-2029

## Prerequisites
- Java 21 (JDK)
- Maven 3.8+
- MongoDB running locally on `mongodb://localhost:27017`
- Postman (optional, for GUI testing) or `curl`

## Project structure
```
crud-springboot-mongodb/
├── pom.xml
├── postman/
│   └── CRUD_Student_MongoDB.postman_collection.json
└── src/main/
    ├── java/com/example/crud/
    │   ├── CrudApplication.java
    │   ├── controller/StudentController.java
    │   ├── model/Student.java
    │   ├── repository/StudentRepository.java
    │   └── exception/
    │       ├── StudentNotFoundException.java
    │       └── GlobalExceptionHandler.java
    └── resources/application.properties
```

## How to run
1. Start MongoDB locally (default port 27017). No manual DB/collection creation
   is needed — Spring Data MongoDB creates the `wad_crud` database and
   `students` collection automatically on first write.
2. From the project root:
   ```bash
   mvn spring-boot:run
   ```
   or build a jar and run it:
   ```bash
   mvn clean package
   java -jar target/crud-springboot-mongodb.jar
   ```
3. The app starts on `http://localhost:8080`.

## How to test
Import `postman/CRUD_Student_MongoDB.postman_collection.json` into Postman.
The collection variable `baseUrl` is already set to `http://localhost:8080`.

Order of testing:
1. **Create Student** (run 3 times using the 3 provided bodies) → copy an
   `id` from a response into the collection variable `studentId`.
2. **Get All Students**
3. **Get Student By ID**
4. **Update Student**
5. **Get Student By ID** again (to see the update)
6. **Delete Student**
7. **Get Student By ID** again (should now return 404)

Equivalent curl commands:
```bash
curl -X POST http://localhost:8080/api/students \
  -H "Content-Type: application/json" \
  -d '{"name":"Sharruk S","registerNumber":"3122247001061","department":"CSE","year":3,"email":"sharruk@example.com"}'

curl http://localhost:8080/api/students

curl http://localhost:8080/api/students/<id>

curl -X PUT http://localhost:8080/api/students/<id> \
  -H "Content-Type: application/json" \
  -d '{"name":"Sharruk S","registerNumber":"3122247001061","department":"CSE","year":3,"email":"updated@example.com"}'

curl -X DELETE http://localhost:8080/api/students/<id>
```

## Note on this build environment
This project was written and packaged inside a sandboxed environment that has
no access to Maven Central and no local MongoDB server, so the build/run/test
cycle above could not be executed live inside that sandbox. The code follows
standard, well-established Spring Boot + Spring Data MongoDB patterns and
compiles against Spring Boot 3.3.4 / Java 21 dependency APIs. You should run
the steps above on your own machine (with internet access and MongoDB
installed) before your lab submission/demo, and capture your own screenshots
for the report.
