package com.example.crud.exception;

/**
 * Thrown when a Student with the given ID does not exist in the database.
 * Mapped to HTTP 404 by GlobalExceptionHandler.
 */
public class StudentNotFoundException extends RuntimeException {

    public StudentNotFoundException(String id) {
        super("Student not found with id: " + id);
    }
}
