package com.example.crud.repository;

import com.example.crud.model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository for Student documents.
 * Spring Data MongoDB automatically implements save(), findAll(),
 * findById(), deleteById(), existsById(), etc.
 */
@Repository
public interface StudentRepository extends MongoRepository<Student, String> {
}
