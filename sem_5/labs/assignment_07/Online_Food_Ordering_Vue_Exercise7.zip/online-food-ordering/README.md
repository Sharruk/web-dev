# Online Food Ordering Application

## Student Details
| Field | Value |
|---|---|
| Student Name | Sharruk S |
| Register Number | 3122247001061 |
| Subject Code | ICS1511 |
| Subject Name | Web Application Development Lab |
| Year / Semester | III Year / V Semester |
| Batch | 2024-2029 |
| Exercise | 7 – Online Food Ordering Application using Vue JS Routing and State Management |

## Problem Statement
Develop a Vue.js Online Food Ordering application with Vue Router, nested routing, and Pinia for state management. The application has a Home page, an Order section, and an About page. The Order section uses nested routing to provide separate pages for the Food Menu and Cart.

## Objectives
- Implement multi-page navigation with Vue Router.
- Demonstrate nested (child) routes under `/order`.
- Manage shared application state (the cart) using Pinia.
- Practice component communication using props and emits.

## Technologies Used
- Vue.js 3 (Composition API, `<script setup>`)
- Vite
- Vue Router 4
- Pinia 2
- Plain CSS

## Features
- Browse a food menu with 4 items (Pizza, Burger, Pasta, Coke).
- Add items to the cart; adding the same item again increases its quantity.
- Increase / decrease quantity, remove an item, or clear the whole cart.
- Live total item count and total bill, computed with Pinia getters.
- Empty-cart message with a link back to the menu.
- Active-route highlighting in the navigation bar.

## Project Structure
```
online-food-ordering/
├── package.json
├── vite.config.js
├── index.html
├── README.md
├── TESTING.md
├── .gitignore
└── src/
    ├── main.js
    ├── App.vue
    ├── style.css
    ├── router/
    │   └── index.js
    ├── stores/
    │   └── cartStore.js
    ├── views/
    │   ├── Home.vue
    │   ├── Order.vue
    │   ├── FoodMenu.vue
    │   ├── Cart.vue
    │   └── About.vue
    └── components/
        └── FoodItem.vue
```

## Route Structure
| Path | Component | Notes |
|---|---|---|
| `/` | `Home.vue` | Landing page |
| `/order` | `Order.vue` | Parent route, holds a `<router-view>` |
| `/order/menu` | `FoodMenu.vue` | Nested child of `/order` |
| `/order/cart` | `Cart.vue` | Nested child of `/order` |
| `/about` | `About.vue` | Static info page |

### Nested Routing Explanation
`Order.vue` is registered as the parent route for `/order` and declares two **children**: `menu` and `cart`. Because they are children, their full paths become `/order/menu` and `/order/cart`, and Vue Router renders whichever child is active inside the `<router-view>` placed directly inside `Order.vue`. This means `Order.vue` acts as a shared layout (title + sub-navigation) for both the Food Menu and the Cart.

## Pinia Store (`src/stores/cartStore.js`)
**State**
- `items`: array of `{ id, name, price, emoji, quantity }`.

**Actions**
- `addToCart(food)` – adds a new item with quantity 1, or increases quantity if it already exists.
- `increaseQuantity(id)` – increases an item's quantity by 1.
- `decreaseQuantity(id)` – decreases an item's quantity by 1, never below 1.
- `removeFromCart(id)` – removes the item completely.
- `clearCart()` – empties the cart.

**Getters**
- `totalItems` – sum of all item quantities.
- `totalBill` – sum of `price * quantity` across all items.

## Installation Steps
```bash
npm install
```

## Running Instructions
```bash
npm run dev
```
Then open the printed local URL (default `http://localhost:5173`) in a browser.

## Testing Instructions
See `TESTING.md` for the full list of manual test cases. In short: browse to each route, add/modify/remove cart items, and confirm the totals and empty-cart message behave as described.

## Expected Output (Cart example)
```
🛒 Cart (3 items)
--------------------------------
🍕 Pizza    [-] 2 [+]    ₹500
🥤 Coke     [-] 1 [+]     ₹80
                    Total: ₹580
              [ Clear Cart ]
```
