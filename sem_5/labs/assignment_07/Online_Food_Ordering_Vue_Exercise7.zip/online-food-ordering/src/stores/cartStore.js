import { defineStore } from 'pinia'

// Pinia store that holds the entire cart state for the app.
// Any component can read from it or call its actions -
// this is the "single source of truth" for the cart.
export const useCartStore = defineStore('cart', {
  // ---------- STATE ----------
  state: () => ({
    items: [] // each item: { id, name, price, emoji, quantity }
  }),

  // ---------- GETTERS ----------
  getters: {
    // Total number of individual food items in the cart
    // (sum of quantities, not just the number of distinct products)
    totalItems: (state) => {
      return state.items.reduce((sum, item) => sum + item.quantity, 0)
    },

    // Total bill = sum of (price * quantity) for every item
    totalBill: (state) => {
      return state.items.reduce((sum, item) => sum + item.price * item.quantity, 0)
    }
  },

  // ---------- ACTIONS ----------
  actions: {
    // Add a food item to the cart.
    // If it's already there, just bump the quantity instead of duplicating it.
    addToCart(food) {
      const existing = this.items.find((item) => item.id === food.id)
      if (existing) {
        existing.quantity++
      } else {
        this.items.push({ ...food, quantity: 1 })
      }
    },

    // Increase quantity of an existing cart item by 1
    increaseQuantity(id) {
      const item = this.items.find((item) => item.id === id)
      if (item) {
        item.quantity++
      }
    },

    // Decrease quantity of an existing cart item by 1.
    // Quantity is never allowed to drop below 1 - use "Remove" for that.
    decreaseQuantity(id) {
      const item = this.items.find((item) => item.id === id)
      if (item && item.quantity > 1) {
        item.quantity--
      }
    },

    // Remove an item from the cart completely, regardless of its quantity
    removeFromCart(id) {
      this.items = this.items.filter((item) => item.id !== id)
    },

    // Empty the entire cart
    clearCart() {
      this.items = []
    }
  }
})
