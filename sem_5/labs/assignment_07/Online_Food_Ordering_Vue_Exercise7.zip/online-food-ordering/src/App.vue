<template>
  <div id="app-shell">
    <header class="navbar">
      <div class="navbar-brand">🍴 FoodExpress</div>
      <nav class="nav-links">
        <RouterLink to="/" class="nav-link">Home</RouterLink>
        <RouterLink to="/order/menu" class="nav-link">Order</RouterLink>
        <RouterLink to="/about" class="nav-link">About</RouterLink>
      </nav>
    </header>

    <main class="page-content">
      <RouterView />
    </main>

    <footer class="app-footer">
      Web Application Development Lab &middot; Exercise 7 &middot; Vue Router + Pinia
    </footer>
  </div>
</template>

<script setup>
// App.vue only handles the overall layout (navbar + footer).
// All page logic lives in the view components, and routing
// is configured separately in src/router/index.js.
</script>

<style>
@import './style.css';
</style>
