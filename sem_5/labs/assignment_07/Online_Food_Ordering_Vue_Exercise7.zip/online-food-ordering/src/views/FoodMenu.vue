<template>
  <div class="food-menu-page">
    <div class="menu-header">
      <h2>Available Food</h2>
      <p class="cart-count-note">🛒 {{ cart.totalItems }} item(s) in cart</p>
    </div>

    <div class="food-list">
      <FoodItem
        v-for="item in foodItems"
        :key="item.id"
        :id="item.id"
        :food="item.name"
        :price="item.price"
        :emoji="item.emoji"
        @add-to-cart="handleAddToCart"
      />
    </div>
  </div>
</template>

<script setup>
import { useCartStore } from '../stores/cartStore'
import FoodItem from '../components/FoodItem.vue'

const cart = useCartStore()

// The four required menu items - id, name, price, emoji
const foodItems = [
  { id: 1, name: 'Pizza', price: 250, emoji: '🍕' },
  { id: 2, name: 'Burger', price: 150, emoji: '🍔' },
  { id: 3, name: 'Pasta', price: 200, emoji: '🍝' },
  { id: 4, name: 'Coke', price: 80, emoji: '🥤' }
]

// FoodItem emits 'add-to-cart' with the food's details;
// we forward that straight into the Pinia store's action.
function handleAddToCart(food) {
  cart.addToCart(food)
}
</script>
