<template>
  <section class="page home-page">
    <div class="hero">
      <h1>🍴 Online Food Ordering</h1>
      <p class="tagline">Order your favorite food easily.</p>
      <RouterLink to="/order/menu" class="btn btn-primary btn-large">
        Browse Food Menu
      </RouterLink>
    </div>

    <div class="home-highlights">
      <div class="highlight-card">
        <span class="highlight-emoji">🍕</span>
        <p>Wide variety of dishes</p>
      </div>
      <div class="highlight-card">
        <span class="highlight-emoji">🛒</span>
        <p>Simple cart management</p>
      </div>
      <div class="highlight-card">
        <span class="highlight-emoji">⚡</span>
        <p>Fast &amp; easy ordering</p>
      </div>
    </div>
  </section>
</template>

<script setup>
// Simple, static Home page - just links out to the Food Menu.
</script>
