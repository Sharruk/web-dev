<template>
  <div class="food-card">
    <div class="food-emoji">{{ emoji }}</div>
    <div class="food-info">
      <h3 class="food-name">{{ food }}</h3>
      <p class="food-price">₹{{ price }}</p>
    </div>
    <button class="btn btn-primary" @click="handleAddToCart">
      Add to Cart
    </button>
  </div>
</template>

<script setup>
// FoodItem receives all its display data via props from FoodMenu.vue
// and simply emits an event when the user clicks "Add to Cart".
// The parent (FoodMenu.vue) decides what to actually do with that event
// (in our case, calling the Pinia store's addToCart action).
const props = defineProps({
  id: { type: Number, required: true },
  food: { type: String, required: true },
  price: { type: Number, required: true },
  emoji: { type: String, required: true }
})

const emit = defineEmits(['add-to-cart'])

function handleAddToCart() {
  emit('add-to-cart', {
    id: props.id,
    name: props.food,
    price: props.price,
    emoji: props.emoji
  })
}
</script>

<style scoped>
.food-card {
  display: flex;
  align-items: center;
  gap: 1rem;
  background: #fff;
  border-radius: 12px;
  padding: 1rem 1.25rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: transform 0.15s ease, box-shadow 0.15s ease;
}

.food-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.12);
}

.food-emoji {
  font-size: 2.2rem;
  line-height: 1;
}

.food-info {
  flex: 1;
}

.food-name {
  margin: 0;
  font-size: 1.05rem;
  color: #2d2d2d;
}

.food-price {
  margin: 0.15rem 0 0;
  color: #e0672c;
  font-weight: 700;
}
</style>
