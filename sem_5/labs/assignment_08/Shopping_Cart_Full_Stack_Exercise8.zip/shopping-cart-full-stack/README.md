# Shopping Cart Full Stack Web Application using VueJs, Spring Boot and MongoDB

## Student Details
| Field | Value |
|---|---|
| Student Name | Sharruk S |
| Register Number | 3122247001061 |
| Subject Code | ICS1511 |
| Subject Name | Web Application Development Lab |
| Year / Semester | III Year / V Semester |
| Batch | 2024-2029 |
| Exercise Number | 8 |

## Problem Statement
A Shopping Cart application that allows users to view products, add products to a cart, update quantities, and remove products from the cart. The application is built with Vue.js (frontend), Spring Boot (backend), and MongoDB (database).

## Objectives
- Build a Vue.js single-page application that displays products and a shopping cart.
- Build a Spring Boot REST API that manages products and cart operations.
- Persist products and cart data in MongoDB.
- Connect the three layers end-to-end using REST + CORS.

## Technologies Used
**Frontend:** Vue.js 3, Vite, JavaScript, HTML, CSS, Axios
**Backend:** Java 21, Spring Boot 3, Spring Web, Spring Data MongoDB, Lombok, Maven
**Database:** MongoDB (local, database `wad_shopping_cart`)

## Architecture
```
Vue.js (localhost:5173)
     │  HTTP (Axios)
     ▼
Spring Boot REST API (localhost:8080)
     │  Spring Data MongoDB
     ▼
MongoDB (localhost:27017 / wad_shopping_cart)
```

## Project Structure
```
shopping-cart-full-stack/
│
├── frontend/                         Vue.js 3 + Vite application
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   └── src/
│       ├── main.js
│       ├── App.vue
│       ├── api.js                    Axios wrapper for all backend calls
│       └── components/
│           ├── Header.vue
│           ├── ProductCard.vue
│           ├── ProductList.vue
│           ├── Cart.vue
│           ├── CartItem.vue
│           └── Footer.vue
│
├── backend/                          Spring Boot application
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/example/shoppingcart/
│       │   ├── ShoppingCartApplication.java
│       │   ├── model/       Product.java, CartItem.java, AddCartRequest.java, UpdateQuantityRequest.java
│       │   ├── repository/  ProductRepository.java, CartRepository.java
│       │   ├── service/     CartService.java
│       │   ├── controller/  ProductController.java, CartController.java
│       │   └── config/      CorsConfig.java, DataSeeder.java
│       └── resources/application.properties
│
├── postman/
│   └── Shopping_Cart_API.postman_collection.json
│
├── report/
│   └── Lab_Report_Exercise8_Shopping_Cart.docx
│
├── README.md
└── TESTING.md
```

## MongoDB Setup
1. Install MongoDB Community Server locally (if not already installed).
2. Start the MongoDB service:
   ```
   mongod --dbpath /path/to/your/data/directory
   ```
   (or start it as a system service, e.g. `sudo systemctl start mongod` on Linux).
3. The application connects to:
   ```
   mongodb://localhost:27017/wad_shopping_cart
   ```
   The database `wad_shopping_cart` and its collections (`products`, `cart`) are created automatically the first time data is written — no manual `mongosh` setup is required.

## Backend Setup
1. Open a terminal in the `backend/` folder.
2. Make sure Java 21 and Maven are installed:
   ```
   java -version
   mvn -version
   ```
3. Run the application:
   ```
   mvn spring-boot:run
   ```
4. On first startup, `DataSeeder` (a `CommandLineRunner`) inserts 8 sample products into the `products` collection **only if the collection is empty**, so restarting the app never creates duplicates.
5. The backend starts on **http://localhost:8080**.

## Frontend Setup
1. Open a terminal in the `frontend/` folder.
2. Install dependencies:
   ```
   npm install
   ```
3. Start the development server:
   ```
   npm run dev
   ```
4. Open the app at **http://localhost:5173**.

> Start MongoDB first, then the backend, then the frontend.

## REST API
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/products` | Get all available products |
| GET | `/api/cart` | Get all cart items |
| POST | `/api/cart` | Add a product to the cart (body: `{ "productId": "..." }`); increases quantity if already present |
| PUT | `/api/cart/{productId}` | Update the quantity of a cart item (body: `{ "quantity": n }`, minimum 1) |
| DELETE | `/api/cart/{productId}` | Remove a product from the cart |
| DELETE | `/api/cart` | Clear the entire cart |
| GET | `/api/cart/total` | Get the total cart amount, `{ "total": n }` |

## How to Run (end-to-end)
1. Start MongoDB: `mongod --dbpath <data-dir>`
2. Start the backend: `cd backend && mvn spring-boot:run`
3. Start the frontend: `cd frontend && npm install && npm run dev`
4. Open `http://localhost:5173` in a browser.
5. Browse products, click **Add to Cart**, adjust quantities with **+ / −**, remove items, or clear the cart. The total updates automatically after every change.

## How to Test with Postman
1. Import `postman/Shopping_Cart_API.postman_collection.json` into Postman.
2. Run **1. Get Products** first and copy a real `_id` from the response.
3. Set the collection variable `productId` to that value (or edit each request's URL/body directly).
4. Run the remaining requests in order (Get Cart → Add → Update Quantity → Remove → Get Total → Clear Cart) to exercise every endpoint.

## How the Frontend Communicates with the Backend
- All backend calls live in `frontend/src/api.js`, a small Axios wrapper pointed at `http://localhost:8080/api`.
- `App.vue` loads products and the cart on mount (`onMounted`), and re-fetches the cart + total after every add/update/remove/clear action, so the UI always reflects what is actually stored in MongoDB.
- `CorsConfig.java` in the backend explicitly allows requests from `http://localhost:5173`, which is required because the frontend and backend run on different ports (different origins) during development.

## How MongoDB Stores Products and Cart
**`products` collection** — one document per product, e.g.:
```json
{ "_id": "66f...", "name": "Laptop", "description": "15-inch laptop, 16GB RAM, 512GB SSD", "price": 55000, "category": "Electronics", "image": "💻" }
```

**`cart` collection** — one document per distinct product currently in the shared/demo cart:
```json
{ "_id": "66f...", "productId": "66f...", "productName": "Laptop", "price": 55000, "quantity": 1 }
```
The item subtotal (`price × quantity`) and the overall cart total (sum of subtotals) are calculated in `CartService` on the backend, not stored redundantly.

## Expected Output
A user can open the app, see the 8 seeded products, add products to the cart, increase/decrease quantities, remove individual items, clear the whole cart, and see the total amount update automatically after every action — with every change persisted in MongoDB via the Spring Boot REST API.

## Known Limitation of This Delivery
This project's source code was written, and the **Vue.js frontend was actually installed and built successfully** (`npm install` + `npm run build` completed without errors) in the environment used to prepare this submission. However, that sandboxed environment does **not** have MongoDB installed, cannot reach Maven Central (needed to download the Spring Boot dependencies), and has no browser automation available. As a result:
- The Spring Boot backend could **not** actually be compiled/run in that environment, and
- No live end-to-end run against MongoDB could be performed, so **no real screenshots of the running full-stack application are included**.

The code follows the exact structure, endpoints, and behaviour described in the assignment, and will run as described once Maven can reach a proper repository and MongoDB is available (i.e., on a normal development machine or lab computer). See `TESTING.md` for the full test plan to run once you have that environment available.
