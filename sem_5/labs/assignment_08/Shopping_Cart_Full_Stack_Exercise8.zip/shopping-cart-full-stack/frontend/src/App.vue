<template>
  <div class="app">
    <Header />

    <p v-if="errorMessage" class="error-banner">{{ errorMessage }}</p>

    <ProductList :products="products" @add-to-cart="handleAddToCart" />

    <Cart
      :cartItems="cartItems"
      :total="total"
      @increase="handleIncrease"
      @decrease="handleDecrease"
      @remove="handleRemove"
      @clear="handleClear"
    />

    <Footer />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import Header from './components/Header.vue'
import Footer from './components/Footer.vue'
import ProductList from './components/ProductList.vue'
import Cart from './components/Cart.vue'
import api from './api'

const products = ref([])
const cartItems = ref([])
const total = ref(0)
const errorMessage = ref('')

// Load products from the Spring Boot backend
async function loadProducts() {
  try {
    const response = await api.getProducts()
    products.value = response.data
  } catch (err) {
    errorMessage.value = 'Could not load products. Is the backend running on http://localhost:8080?'
  }
}

// Load the cart items from the backend
async function loadCart() {
  try {
    const response = await api.getCart()
    cartItems.value = response.data
  } catch (err) {
    errorMessage.value = 'Could not load the cart. Is the backend running on http://localhost:8080?'
  }
}

// Load the total from the backend
async function loadTotal() {
  try {
    const response = await api.getTotal()
    total.value = response.data.total
  } catch (err) {
    errorMessage.value = 'Could not load the cart total.'
  }
}

// Refresh cart + total together after any cart-modifying action
async function refreshCart() {
  await loadCart()
  await loadTotal()
}

async function handleAddToCart(productId) {
  errorMessage.value = ''
  try {
    await api.addToCart(productId)
    await refreshCart()
  } catch (err) {
    errorMessage.value = 'Could not add the product to the cart.'
  }
}

async function handleIncrease(productId) {
  const item = cartItems.value.find((i) => i.productId === productId)
  if (!item) return
  try {
    await api.updateQuantity(productId, item.quantity + 1)
    await refreshCart()
  } catch (err) {
    errorMessage.value = 'Could not update the quantity.'
  }
}

async function handleDecrease(productId) {
  const item = cartItems.value.find((i) => i.productId === productId)
  if (!item) return
  // Do not allow quantity below 1
  const newQuantity = Math.max(item.quantity - 1, 1)
  try {
    await api.updateQuantity(productId, newQuantity)
    await refreshCart()
  } catch (err) {
    errorMessage.value = 'Could not update the quantity.'
  }
}

async function handleRemove(productId) {
  try {
    await api.removeFromCart(productId)
    await refreshCart()
  } catch (err) {
    errorMessage.value = 'Could not remove the product from the cart.'
  }
}

async function handleClear() {
  try {
    await api.clearCart()
    await refreshCart()
  } catch (err) {
    errorMessage.value = 'Could not clear the cart.'
  }
}

onMounted(async () => {
  await loadProducts()
  await refreshCart()
})
</script>

<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: 'Segoe UI', Arial, sans-serif;
  background-color: #f4f6f7;
}

.app {
  max-width: 1000px;
  margin: 0 auto;
  background: white;
  min-height: 100vh;
}

.error-banner {
  background-color: #fdecea;
  color: #c0392b;
  padding: 10px 30px;
  margin: 0;
  font-size: 0.9rem;
}
</style>
