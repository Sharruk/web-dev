<template>
  <section class="cart-section">
    <h2>Shopping Cart</h2>

    <div v-if="cartItems.length === 0" class="empty-cart">
      Your cart is empty. Add some products!
    </div>

    <div v-else>
      <CartItem
        v-for="item in cartItems"
        :key="item.productId"
        :item="item"
        @increase="(id) => $emit('increase', id)"
        @decrease="(id) => $emit('decrease', id)"
        @remove="(id) => $emit('remove', id)"
      />

      <div class="cart-total">
        <span>Total:</span>
        <span class="total-amount">₹{{ total.toLocaleString('en-IN') }}</span>
      </div>

      <button class="clear-btn" @click="$emit('clear')">Clear Cart</button>
    </div>
  </section>
</template>

<script setup>
import CartItem from './CartItem.vue'

defineProps({
  cartItems: {
    type: Array,
    required: true
  },
  total: {
    type: Number,
    required: true
  }
})

defineEmits(['increase', 'decrease', 'remove', 'clear'])
</script>

<style scoped>
.cart-section {
  padding: 20px 30px;
  background: #fafafa;
}

.empty-cart {
  color: #999;
  padding: 20px 0;
}

.cart-total {
  display: flex;
  justify-content: space-between;
  font-size: 1.2rem;
  font-weight: bold;
  padding: 16px 0;
  border-top: 2px solid #2c3e50;
  margin-top: 10px;
}

.total-amount {
  color: #27ae60;
}

.clear-btn {
  background-color: #7f8c8d;
  color: white;
  border: none;
  padding: 10px 16px;
  border-radius: 5px;
  cursor: pointer;
  width: 100%;
  font-size: 0.95rem;
}

.clear-btn:hover {
  background-color: #616a6b;
}
</style>
