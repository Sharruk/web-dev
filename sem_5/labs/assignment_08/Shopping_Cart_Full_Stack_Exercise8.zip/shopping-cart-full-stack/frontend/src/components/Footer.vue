<template>
  <footer class="app-footer">
    <p>Sharruk S &middot; 3122247001061 &middot; ICS1511 Web Application Development Lab &middot; Exercise 8</p>
  </footer>
</template>

<script setup>
</script>

<style scoped>
.app-footer {
  text-align: center;
  padding: 14px;
  color: #7f8c8d;
  font-size: 0.8rem;
  border-top: 1px solid #ecf0f1;
  margin-top: 30px;
}
</style>
