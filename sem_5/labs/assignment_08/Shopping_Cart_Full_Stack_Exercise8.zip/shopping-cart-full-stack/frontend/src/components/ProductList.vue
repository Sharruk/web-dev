<template>
  <section class="product-section">
    <h2>Available Products</h2>

    <p v-if="products.length === 0" class="empty-msg">
      No products available right now.
    </p>

    <div v-else class="product-grid">
      <ProductCard
        v-for="product in products"
        :key="product.id"
        :product="product"
        @add-to-cart="(id) => $emit('add-to-cart', id)"
      />
    </div>
  </section>
</template>

<script setup>
import ProductCard from './ProductCard.vue'

defineProps({
  products: {
    type: Array,
    required: true
  }
})

defineEmits(['add-to-cart'])
</script>

<style scoped>
.product-section {
  padding: 20px 30px;
}

.product-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 16px;
}

.empty-msg {
  color: #999;
}
</style>
