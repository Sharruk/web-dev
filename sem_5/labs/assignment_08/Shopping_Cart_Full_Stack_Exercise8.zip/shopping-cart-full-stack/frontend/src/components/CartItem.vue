<template>
  <div class="cart-item">
    <div class="item-info">
      <p class="item-name">{{ item.productName }}</p>
      <p class="item-price">₹{{ item.price.toLocaleString('en-IN') }}</p>
    </div>

    <div class="item-quantity">
      <button @click="$emit('decrease', item.productId)">−</button>
      <span>{{ item.quantity }}</span>
      <button @click="$emit('increase', item.productId)">+</button>
    </div>

    <div class="item-subtotal">
      Subtotal: ₹{{ subtotal.toLocaleString('en-IN') }}
    </div>

    <button class="remove-btn" @click="$emit('remove', item.productId)">
      Remove
    </button>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  item: {
    type: Object,
    required: true
  }
})

defineEmits(['increase', 'decrease', 'remove'])

const subtotal = computed(() => props.item.price * props.item.quantity)
</script>

<style scoped>
.cart-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 0;
  border-bottom: 1px solid #ecf0f1;
  gap: 10px;
  flex-wrap: wrap;
}

.item-info {
  min-width: 120px;
}

.item-name {
  font-weight: 600;
  margin: 0;
}

.item-price {
  margin: 2px 0 0;
  color: #666;
  font-size: 0.85rem;
}

.item-quantity {
  display: flex;
  align-items: center;
  gap: 8px;
}

.item-quantity button {
  width: 28px;
  height: 28px;
  border: 1px solid #ccc;
  background: #f8f8f8;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1rem;
}

.item-subtotal {
  font-weight: 600;
  color: #27ae60;
  min-width: 120px;
}

.remove-btn {
  background-color: #e74c3c;
  color: white;
  border: none;
  padding: 6px 10px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 0.85rem;
}

.remove-btn:hover {
  background-color: #c0392b;
}
</style>
