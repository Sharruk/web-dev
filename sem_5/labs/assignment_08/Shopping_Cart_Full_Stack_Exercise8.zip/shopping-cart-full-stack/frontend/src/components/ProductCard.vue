<template>
  <div class="product-card">
    <div class="product-image">{{ product.image || '📦' }}</div>
    <h3>{{ product.name }}</h3>
    <p class="description">{{ product.description }}</p>
    <p class="category">{{ product.category }}</p>
    <p class="price">₹{{ product.price.toLocaleString('en-IN') }}</p>
    <button class="add-btn" @click="$emit('add-to-cart', product.id)">
      Add to Cart
    </button>
  </div>
</template>

<script setup>
defineProps({
  product: {
    type: Object,
    required: true
  }
})

defineEmits(['add-to-cart'])
</script>

<style scoped>
.product-card {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 16px;
  text-align: center;
  background: #ffffff;
  display: flex;
  flex-direction: column;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
}

.product-image {
  font-size: 2.5rem;
  margin-bottom: 8px;
}

.product-card h3 {
  margin: 4px 0;
  font-size: 1.05rem;
}

.description {
  font-size: 0.85rem;
  color: #666;
  flex-grow: 1;
}

.category {
  font-size: 0.75rem;
  color: #999;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.price {
  font-weight: bold;
  font-size: 1.15rem;
  color: #27ae60;
  margin: 8px 0;
}

.add-btn {
  background-color: #2980b9;
  color: white;
  border: none;
  padding: 8px 12px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 0.9rem;
}

.add-btn:hover {
  background-color: #21618c;
}
</style>
