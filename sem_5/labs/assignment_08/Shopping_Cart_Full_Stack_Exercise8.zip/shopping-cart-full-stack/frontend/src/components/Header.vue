<template>
  <header class="app-header">
    <h1>🛒 WAD Shopping Cart</h1>
    <p class="subtitle">Vue.js + Spring Boot + MongoDB &mdash; Exercise 8</p>
  </header>
</template>

<script setup>
</script>

<style scoped>
.app-header {
  background-color: #2c3e50;
  color: #ffffff;
  padding: 20px 30px;
  text-align: center;
}

.app-header h1 {
  margin: 0;
  font-size: 1.8rem;
}

.subtitle {
  margin: 4px 0 0;
  font-size: 0.9rem;
  color: #bdc3c7;
}
</style>
