import axios from 'axios'

// Base URL of the Spring Boot backend (see CORS setup in the backend)
const api = axios.create({
  baseURL: 'http://localhost:8080/api'
})

export default {
  getProducts() {
    return api.get('/products')
  },
  getCart() {
    return api.get('/cart')
  },
  addToCart(productId) {
    return api.post('/cart', { productId })
  },
  updateQuantity(productId, quantity) {
    return api.put(`/cart/${productId}`, { quantity })
  },
  removeFromCart(productId) {
    return api.delete(`/cart/${productId}`)
  },
  clearCart() {
    return api.delete('/cart')
  },
  getTotal() {
    return api.get('/cart/total')
  }
}
