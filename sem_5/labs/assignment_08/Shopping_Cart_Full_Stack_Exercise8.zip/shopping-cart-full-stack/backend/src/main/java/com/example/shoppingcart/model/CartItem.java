package com.example.shoppingcart.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Represents a product that has been added to the shared/demo shopping cart.
 * Stored in the "cart" collection of the wad_shopping_cart database.
 *
 * The lab does not require a login system, so a single shared cart is used.
 */
@Document("cart")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CartItem {

    @Id
    private String id;

    private String productId;
    private String productName;
    private double price;
    private int quantity;

    public double getSubtotal() {
        return price * quantity;
    }
}
