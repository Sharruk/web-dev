package com.example.shoppingcart.service;

import com.example.shoppingcart.model.CartItem;
import com.example.shoppingcart.model.Product;
import com.example.shoppingcart.repository.CartRepository;
import com.example.shoppingcart.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

/**
 * Contains the business logic for shopping cart operations:
 * adding items, updating quantities, removing items, clearing the
 * cart and calculating the total cart amount.
 */
@Service
@RequiredArgsConstructor
public class CartService {

    private final CartRepository cartRepository;
    private final ProductRepository productRepository;

    /** Returns every item currently in the shared/demo cart. */
    public List<CartItem> getCart() {
        return cartRepository.findAll();
    }

    /**
     * Adds a product to the cart.
     * - If the product does not exist in the cart yet, it is added with quantity 1.
     * - If it already exists, its quantity is increased by 1.
     */
    public CartItem addToCart(String productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new NoSuchElementException("Product not found: " + productId));

        return cartRepository.findByProductId(productId)
                .map(existingItem -> {
                    existingItem.setQuantity(existingItem.getQuantity() + 1);
                    return cartRepository.save(existingItem);
                })
                .orElseGet(() -> {
                    CartItem newItem = new CartItem(
                            null,
                            product.getId(),
                            product.getName(),
                            product.getPrice(),
                            1
                    );
                    return cartRepository.save(newItem);
                });
    }

    /**
     * Updates the quantity of a cart item.
     * Quantity is never allowed to go below 1 (use removeFromCart to delete an item).
     */
    public CartItem updateQuantity(String productId, int quantity) {
        CartItem item = cartRepository.findByProductId(productId)
                .orElseThrow(() -> new NoSuchElementException("Product not in cart: " + productId));

        int safeQuantity = Math.max(quantity, 1);
        item.setQuantity(safeQuantity);
        return cartRepository.save(item);
    }

    /** Removes a single product from the cart. */
    public void removeFromCart(String productId) {
        cartRepository.deleteByProductId(productId);
    }

    /** Removes every item from the cart. */
    public void clearCart() {
        cartRepository.deleteAll();
    }

    /** Calculates the total cart amount as the sum of (price * quantity) for every item. */
    public double getTotal() {
        return cartRepository.findAll()
                .stream()
                .mapToDouble(CartItem::getSubtotal)
                .sum();
    }
}
