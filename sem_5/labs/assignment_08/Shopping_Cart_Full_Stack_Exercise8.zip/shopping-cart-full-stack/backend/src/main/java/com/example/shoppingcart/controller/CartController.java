package com.example.shoppingcart.controller;

import com.example.shoppingcart.model.AddCartRequest;
import com.example.shoppingcart.model.CartItem;
import com.example.shoppingcart.model.UpdateQuantityRequest;
import com.example.shoppingcart.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/cart")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:5173")
public class CartController {

    private final CartService cartService;

    /** GET /api/cart - returns all items currently in the cart. */
    @GetMapping
    public List<CartItem> getCart() {
        return cartService.getCart();
    }

    /** POST /api/cart - adds a product to the cart (or increases its quantity). */
    @PostMapping
    public ResponseEntity<CartItem> addToCart(@RequestBody AddCartRequest request) {
        CartItem item = cartService.addToCart(request.getProductId());
        return ResponseEntity.status(HttpStatus.CREATED).body(item);
    }

    /** PUT /api/cart/{productId} - updates the quantity of a cart item. */
    @PutMapping("/{productId}")
    public ResponseEntity<CartItem> updateQuantity(@PathVariable String productId,
                                                     @RequestBody UpdateQuantityRequest request) {
        CartItem item = cartService.updateQuantity(productId, request.getQuantity());
        return ResponseEntity.ok(item);
    }

    /** DELETE /api/cart/{productId} - removes a single product from the cart. */
    @DeleteMapping("/{productId}")
    public ResponseEntity<Void> removeFromCart(@PathVariable String productId) {
        cartService.removeFromCart(productId);
        return ResponseEntity.noContent().build();
    }

    /** DELETE /api/cart - clears the entire cart. */
    @DeleteMapping
    public ResponseEntity<Void> clearCart() {
        cartService.clearCart();
        return ResponseEntity.noContent().build();
    }

    /** GET /api/cart/total - returns the total cart amount. */
    @GetMapping("/total")
    public ResponseEntity<Map<String, Double>> getTotal() {
        return ResponseEntity.ok(Map.of("total", cartService.getTotal()));
    }

    /** Handles the case where a product/cart item cannot be found. */
    @ExceptionHandler(NoSuchElementException.class)
    public ResponseEntity<Map<String, String>> handleNotFound(NoSuchElementException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", ex.getMessage()));
    }
}
