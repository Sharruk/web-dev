package com.example.shoppingcart.model;

import lombok.Data;

/** Request body for POST /api/cart */
@Data
public class AddCartRequest {
    private String productId;
}
