package com.example.shoppingcart.model;

import lombok.Data;

/** Request body for PUT /api/cart/{productId} */
@Data
public class UpdateQuantityRequest {
    private int quantity;
}
