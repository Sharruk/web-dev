package com.example.shoppingcart.config;

import com.example.shoppingcart.model.Product;
import com.example.shoppingcart.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Seeds the "products" collection with sample data on startup.
 * Runs only when the collection is empty, so restarting the
 * application never creates duplicate products.
 */
@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final ProductRepository productRepository;

    @Override
    public void run(String... args) {
        if (productRepository.count() > 0) {
            return; // sample data already present
        }

        List<Product> sampleProducts = List.of(
                new Product(null, "Laptop", "15-inch laptop, 16GB RAM, 512GB SSD", 55000, "Electronics", "\uD83D\uDCBB"),
                new Product(null, "Smartphone", "6.5-inch display, 128GB storage", 25000, "Electronics", "\uD83D\uDCF1"),
                new Product(null, "Headphones", "Over-ear wireless headphones", 2500, "Accessories", "\uD83C\uDFA7"),
                new Product(null, "Keyboard", "Mechanical keyboard with RGB backlight", 1500, "Accessories", "\u2328\uFE0F"),
                new Product(null, "Mouse", "Wireless optical mouse", 800, "Accessories", "\uD83D\uDDB1\uFE0F"),
                new Product(null, "Monitor", "24-inch Full HD LED monitor", 12000, "Electronics", "\uD83D\uDDA5\uFE0F"),
                new Product(null, "USB Cable", "Type-C fast charging cable, 1m", 500, "Accessories", "\uD83D\uDD0C"),
                new Product(null, "Power Bank", "10000mAh portable power bank", 1800, "Accessories", "\uD83D\uDD0B")
        );

        productRepository.saveAll(sampleProducts);
    }
}
