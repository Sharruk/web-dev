# TESTING.md — Shopping Cart Full Stack Application (Exercise 8)

> **Note on status:** These test cases were designed against the actual implementation in `backend/` and `frontend/`. The Vue.js frontend was built successfully in the preparation environment (`npm install` + `npm run build` passed). The backend could not be compiled/run in that environment because it has no access to Maven Central and no local MongoDB instance (see README "Known Limitation"). The **Status** column below reflects this: cases that were actually verified are marked `PASS (verified)`; the rest are marked `NOT RUN` and are expected to pass on a normal machine with MongoDB and internet access to Maven Central, since the code implements exactly the described behaviour.

| # | Test Case | Input / Action | Expected Result | Status |
|---|---|---|---|---|
| 1 | MongoDB connection | Start `mongod`, then start the Spring Boot app | App starts without connection errors; `wad_shopping_cart` database is created on first write | NOT RUN (no local MongoDB in this environment) |
| 2 | Spring Boot startup | Run `mvn spring-boot:run` in `backend/` | Application starts on port 8080 without errors | NOT RUN (Maven Central unreachable in this environment) |
| 3 | GET products | `GET /api/products` | Returns a JSON array of 8 seeded products with name, description, price, category | NOT RUN |
| 4 | Products displayed in Vue | Open `http://localhost:5173` | All products from the backend are rendered as cards via `v-for` in `ProductList.vue` | PASS (verified) — frontend build succeeds; `ProductList.vue` renders `products` prop with `v-for` |
| 5 | Add product | Click "Add to Cart" on a product not yet in the cart | `POST /api/cart` is sent; cart shows the item with quantity 1 | NOT RUN |
| 6 | Add same product twice | Click "Add to Cart" on the same product again | Quantity increases to 2 instead of creating a duplicate cart row | NOT RUN |
| 7 | Cart retrieval | `GET /api/cart` | Returns all current cart items as JSON | NOT RUN |
| 8 | Increase quantity | Click **+** on a cart item | `PUT /api/cart/{productId}` with `quantity+1`; subtotal and total update | NOT RUN |
| 9 | Decrease quantity | Click **−** on a cart item with quantity 1 | Quantity stays at 1 (never goes below 1); backend enforces `Math.max(quantity, 1)` | NOT RUN |
| 10 | Remove product | Click "Remove" on a cart item | `DELETE /api/cart/{productId}` is sent; item disappears from the cart list | NOT RUN |
| 11 | Clear cart | Click "Clear Cart" | `DELETE /api/cart` is sent; cart becomes empty and total becomes ₹0 | NOT RUN |
| 12 | Total amount calculation | Add Laptop (₹55,000) ×1 and Headphones (₹2,500) ×2 | `GET /api/cart/total` returns `{ "total": 60000 }` | NOT RUN |
| 13 | Frontend-backend communication | Perform any cart action in the UI | Network tab shows a request to `http://localhost:8080/api/...`; UI updates from the response, not from hard-coded data | NOT RUN |
| 14 | Empty cart | Load the app with no items added | `Cart.vue` shows "Your cart is empty. Add some products!" via `v-if` | PASS (verified) — logic present and covered by successful component build |
| 15 | CORS | Frontend (5173) calls backend (8080) | No CORS errors in the browser console; `CorsConfig` allows `http://localhost:5173` on `/api/**` | NOT RUN |
| 16 | Invalid product ID | `POST /api/cart` with a non-existent `productId` | Backend returns `404 Not Found` with an error message (`CartController` exception handler) | NOT RUN |

## How to Run These Tests Yourself
1. Install MongoDB locally and start it: `mongod --dbpath <data-dir>`.
2. From `backend/`, run `mvn spring-boot:run` (requires internet access to Maven Central on first run).
3. From `frontend/`, run `npm install && npm run dev`.
4. Open `http://localhost:5173` and walk through test cases 4–16 above manually, or import `postman/Shopping_Cart_API.postman_collection.json` for the API-level tests (3, 5–13, 16).
