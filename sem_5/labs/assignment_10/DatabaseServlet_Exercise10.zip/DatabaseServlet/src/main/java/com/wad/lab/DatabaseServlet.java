package com.wad.lab;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * DatabaseServlet
 * -----------------------------------------------------------------------
 * Exercise 10 - Database Servlet Application using Tomcat Server.
 *
 * This servlet responds to a GET request (submitted from index.html),
 * connects to the MySQL database "wad_database_servlet" using JDBC,
 * executes "SELECT * FROM employees" and renders the results as an
 * HTML table in the response.
 *
 * Student   : Sharruk S
 * Reg. No   : 3122247001061
 * Subject   : ICS1511 - Web Application Development Lab
 * -----------------------------------------------------------------------
 *
 * NOTE ON JDBC CONFIGURATION:
 * The DB_URL, DB_USERNAME and DB_PASSWORD constants below are placeholders
 * for local development. Do NOT commit real production credentials here.
 * Replace DB_PASSWORD with your own local MySQL password before deploying.
 *
 * This servlet is intentionally mapped ONLY through WEB-INF/web.xml
 * (no @WebServlet annotation) to satisfy the assignment's requirement
 * of a traditional web.xml-based servlet mapping.
 */
public class DatabaseServlet extends HttpServlet {

    // ---------------------------------------------------------------
    // JDBC configuration (edit these three values for your machine)
    // ---------------------------------------------------------------
    private static final String DB_URL =
            "jdbc:mysql://localhost:3306/wad_database_servlet?useSSL=false&serverTimezone=UTC";
    private static final String DB_USERNAME = "wad_user";      // <-- DB_USERNAME
    private static final String DB_PASSWORD = "CHANGE_ME";     // <-- DB_PASSWORD (replace locally)

    // Fully-qualified JDBC driver class name for MySQL Connector/J 8+/9+.
    // (Connector/J 6+ drivers self-register via ServiceLoader, so
    //  Class.forName() is not strictly required, but it is kept here
    //  for compatibility with older driver versions and for clarity.)
    private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";

    /**
     * Handles the GET request produced when the user clicks
     * "Display Employee Records" on index.html.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        // Try to load the JDBC driver class. If it is missing from
        // WEB-INF/lib, fail gracefully with a clear message instead of
        // throwing an uncaught ClassNotFoundException.
        try {
            Class.forName(JDBC_DRIVER);
        } catch (ClassNotFoundException e) {
            sendErrorPage(response,
                    "JDBC driver not found. Make sure the MySQL Connector/J "
                  + "jar is present in WEB-INF/lib or Tomcat's lib folder.");
            return;
        }

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try (PrintWriter out = response.getWriter()) {

            // 1. Open the JDBC connection to MySQL.
            connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);

            // 2. Prepare and execute the SELECT query.
            String sql = "SELECT id, age, first, last FROM employees ORDER BY id";
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            // 3. Begin building the HTML response.
            out.println("<!DOCTYPE html>");
            out.println("<html><head><title>Employee Records</title>");
            out.println(buildInlineCss());
            out.println("</head><body>");
            out.println("<div class='container'>");
            out.println("<h1>Employee Records</h1>");
            out.println("<table>");
            out.println("<tr><th>ID</th><th>Age</th><th>First Name</th><th>Last Name</th></tr>");

            // 4. Iterate through the ResultSet and render each row.
            int rowCount = 0;
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                int age = resultSet.getInt("age");
                String first = resultSet.getString("first");
                String last = resultSet.getString("last");

                out.println("<tr>");
                out.println("<td>" + id + "</td>");
                out.println("<td>" + age + "</td>");
                out.println("<td>" + escapeHtml(first) + "</td>");
                out.println("<td>" + escapeHtml(last) + "</td>");
                out.println("</tr>");
                rowCount++;
            }

            out.println("</table>");

            if (rowCount == 0) {
                out.println("<p class='empty'>No employee records were found.</p>");
            } else {
                out.println("<p class='count'>Total records: " + rowCount + "</p>");
            }

            out.println("<a class='back' href='index.html'>&larr; Back</a>");
            out.println("</div>");
            out.println("</body></html>");

        } catch (SQLException e) {
            // Handle database errors gracefully without exposing credentials.
            sendErrorPage(response, "Unable to connect to the database. "
                    + "Please verify that MySQL is running and the "
                    + "database 'wad_database_servlet' exists.");
            // Server-side log only (never shown to the client).
            e.printStackTrace();
        } finally {
            // 5. Always close JDBC resources in reverse order of creation.
            closeQuietly(resultSet);
            closeQuietly(statement);
            closeQuietly(connection);
        }
    }

    /** Writes a simple, safe error page to the client. */
    private void sendErrorPage(HttpServletResponse response, String message) throws IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html><html><head><title>Error</title>");
        out.println(buildInlineCss());
        out.println("</head><body><div class='container'>");
        out.println("<h1>Database Error</h1>");
        out.println("<p class='error'>" + escapeHtml(message) + "</p>");
        out.println("<a class='back' href='index.html'>&larr; Back</a>");
        out.println("</div></body></html>");
        out.flush();
    }

    /** Small inline CSS shared by the results and error pages. */
    private String buildInlineCss() {
        return "<style>"
             + "body{font-family:Arial,Helvetica,sans-serif;background:#f4f6f8;margin:0;padding:40px;}"
             + ".container{max-width:700px;margin:0 auto;background:#fff;padding:30px 40px;"
             + "border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.15);}"
             + "h1{color:#2c3e50;}"
             + "table{border-collapse:collapse;width:100%;margin-top:15px;}"
             + "th,td{border:1px solid #ccc;padding:10px;text-align:center;}"
             + "th{background:#2980b9;color:#fff;}"
             + "tr:nth-child(even){background:#f2f2f2;}"
             + ".count{color:#555;margin-top:12px;}"
             + ".error{color:#c0392b;font-weight:bold;}"
             + ".empty{color:#888;}"
             + ".back{display:inline-block;margin-top:20px;color:#2980b9;text-decoration:none;}"
             + ".back:hover{text-decoration:underline;}"
             + "</style>";
    }

    /** Minimal HTML-escaping helper to avoid injecting raw text into the page. */
    private String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;");
    }

    /** Utility to close JDBC resources without throwing from the finally block. */
    private void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception ignored) {
                // Logging only; closing failures should not affect the response already sent.
            }
        }
    }
}
