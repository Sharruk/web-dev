-- =========================================================
-- Exercise 10: Database Servlet Application - MySQL Setup
-- Student: Sharruk S | Reg No: 3122247001061
-- =========================================================

-- 1. Create the database
CREATE DATABASE IF NOT EXISTS wad_database_servlet;

USE wad_database_servlet;

-- 2. Create the employees table
-- NOTE: the original assignment text contains a typo ("Employess" vs
-- "Employees"). The correctly spelled table name "employees" is used
-- consistently throughout this project.
CREATE TABLE IF NOT EXISTS employees (
    id    INT PRIMARY KEY,
    age   INT,
    first VARCHAR(20),
    last  VARCHAR(20)
);

-- 3. Insert sample records
INSERT INTO employees (id, age, first, last) VALUES
    (101, 20, 'Zara',  'Ali'),
    (102, 22, 'John',  'Smith'),
    (103, 21, 'Anita', 'Kumar'),
    (104, 23, 'Rahul', 'Sharma')
ON DUPLICATE KEY UPDATE first = VALUES(first);

-- 4. Verify
SELECT * FROM employees;

-- =========================================================
-- 5. (Optional but recommended) Create a dedicated application
--    user instead of connecting to MySQL as root from the servlet.
--    Replace 'CHANGE_ME' with your own strong local password and
--    update the same password in DatabaseServlet.java (DB_PASSWORD).
-- =========================================================
CREATE USER IF NOT EXISTS 'wad_user'@'localhost' IDENTIFIED BY 'CHANGE_ME';
GRANT ALL PRIVILEGES ON wad_database_servlet.* TO 'wad_user'@'localhost';
FLUSH PRIVILEGES;
