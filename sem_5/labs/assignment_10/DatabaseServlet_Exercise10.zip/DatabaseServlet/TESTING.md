# TESTING.md — Exercise 10: Database Servlet Application

All test cases below marked **PASS** were executed for real against a live
MySQL 8.0 + Apache Tomcat 10 deployment in the build environment (see
`README.md` section 22 and the `evidence/` folder for raw proof). Test cases
that describe a real-machine-only concern (e.g. a specific OS restart
procedure) are marked accordingly.

| # | Test Case | Action / Input | Expected Result | Status |
|---|---|---|---|---|
| 1 | MySQL service running | Run `mysqladmin ping` | Server responds "mysqld is alive" | **PASS** — confirmed live |
| 2 | Database exists | Run `SHOW DATABASES;` | `wad_database_servlet` is listed | **PASS** — confirmed live |
| 3 | `employees` table exists | Run `SHOW TABLES;` in `wad_database_servlet` | `employees` is listed | **PASS** — confirmed live |
| 4 | Sample records exist | Run `SELECT * FROM employees;` | 4 rows returned (101–104) | **PASS** — confirmed live, see `evidence/screenshots/01_mysql.png` |
| 5 | Tomcat starts | Run `catalina.sh start` | Log shows "Server startup in [n] milliseconds" with no errors | **PASS** — confirmed live, see `evidence/screenshots/06_tomcat_deploy.png` |
| 6 | Application deploys | Copy app to `webapps/DatabaseServlet/` and restart Tomcat | Catalina log shows "Deployment of web application directory [...DatabaseServlet] has finished" | **PASS** — confirmed live |
| 7 | `index.html` loads | `GET http://localhost:8080/DatabaseServlet/` | HTTP 200, form with submit button rendered | **PASS** — HTTP 200 confirmed via curl, see `evidence/screenshots/shot3_index_page.png` |
| 8 | Form uses GET method | Inspect `index.html` form tag | `<form action="DatabaseServlet" method="get">` | **PASS** — verified in source |
| 9 | Submit button works | Click "Display Employee Records" in a browser | Browser navigates to `DatabaseServlet` endpoint | **PASS (by construction)** — equivalent GET request issued via curl and confirmed working; no graphical browser is available in this sandbox to click the literal button (see README §22) |
| 10 | Servlet receives GET request | `curl -v -X GET http://localhost:8080/DatabaseServlet/DatabaseServlet` | Request line shows `> GET /DatabaseServlet/DatabaseServlet HTTP/1.1`; response `HTTP/1.1 200` | **PASS** — confirmed live, see `evidence/screenshots/04_get_request.png` |
| 11 | JDBC connection works | Servlet calls `DriverManager.getConnection(...)` | Connection object returned without exception | **PASS** — confirmed live (proxied through a compatible JDBC driver for this sandbox's network restrictions — see README §22) |
| 12 | `SELECT` query works | Servlet executes `SELECT id, age, first, last FROM employees ORDER BY id` | `ResultSet` contains 4 rows | **PASS** — confirmed live |
| 13 | Records displayed | Load servlet endpoint in browser | HTML table with employee data visible | **PASS** — confirmed live, see `evidence/screenshots/shot5_records_page.png` |
| 14 | Multiple records displayed | Same as above | All 4 rows (101, 102, 103, 104) appear, not just one | **PASS** — all 4 rows present in the live response |
| 15 | Database connection error handling | Stop MySQL, then hit the servlet endpoint | Friendly "Unable to connect to the database" page, HTTP 200, **no password/URL leaked** | **PASS** — confirmed live; grep of the error response for the password/URL found nothing |
| 16 | Servlet URL mapping works | Request `/DatabaseServlet/DatabaseServlet` per `web.xml` `<url-pattern>` | Request is routed to `DatabaseServlet.doGet()` | **PASS** — confirmed live (HTTP 200 + correct table returned) |
| 17 | Application works after restarting Tomcat | Stop and restart Tomcat, then repeat test #7 and #13 | Same successful results after restart | **PASS** — confirmed live across two separate Tomcat restarts during this verification session |

## Notes on Test Execution Environment
- Tests 1–8, 10–17 were executed against a genuinely running MySQL 8.0 and
  Apache Tomcat 10 instance using `curl` for all HTTP-level checks.
- Test 9 (physically clicking a button in a graphical browser) could not be
  performed literally because this build/verification sandbox has no display
  or browser — it was substituted with the HTTP-equivalent action (issuing
  the same GET request the browser would issue), which is the behaviour the
  test is actually checking.
- Test 11's JDBC driver substitution is documented in `README.md` (section
  22) and does not affect the servlet source delivered for grading.
