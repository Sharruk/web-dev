# Database Servlet Application using Tomcat Server

## 1. Project Title
**Database Servlet Application using Tomcat Server** (Exercise 10)

## 2. Student Details
| Field | Value |
|---|---|
| Student Name | Sharruk S |
| Register Number | 3122247001061 |
| Subject Code | ICS1511 |
| Subject Name | Web Application Development Lab |
| Year / Semester | III Year / V Semester |
| Batch | 2024-2029 |

## 3. Exercise Number
Exercise 10

## 4. Problem Statement
Write `index.html` to display a form with a submit button whose `method`
attribute is `"get"`. Write a Java Servlet that, when the button is clicked,
connects to a MySQL database and displays the records of a table. Write the
`web.xml` configuration file that maps the servlet's URL.

## 5. Aim
To design and deploy a traditional Java Servlet web application on Apache
Tomcat that retrieves and displays records from a MySQL database in response
to an HTTP GET request.

## 6. Objectives
- Build an HTML form that issues a GET request.
- Write a servlet that handles `doGet()`, connects to MySQL via JDBC, and
  renders the result set as an HTML table.
- Configure servlet mapping using `web.xml` (no annotation-based mapping).
- Deploy and verify the application on Apache Tomcat.

## 7. Technologies Used
- HTML5 / CSS3
- Java Servlet (Jakarta Servlet API)
- JDBC (Java Database Connectivity)
- MySQL
- Apache Tomcat

## 8. Software Requirements
- JDK 17+ (JDK 21 used here)
- Apache Tomcat 10.x
- MySQL Server 8.x
- MySQL Connector/J (JDBC driver)
- A text editor / IDE (Eclipse, IntelliJ, VS Code, etc.)

## 9. Selected Versions
| Component | Version Selected | Reason |
|---|---|---|
| Java (JDK) | 21 (OpenJDK) | Current LTS available in the build environment |
| Apache Tomcat | **10.1.55** | Tomcat 9 is not available as a package on Ubuntu 24.04; Tomcat 10 is, and it uses the modern **Jakarta EE** namespace |
| MySQL Server | **8.0.46** | Current stable MySQL release available in the environment; MySQL 5.5 (mentioned in the original lab sheet) is obsolete and unsupported |
| Servlet API | **Jakarta Servlet 6.0** (`jakarta.servlet.*`) | Required because Tomcat 10+ moved from `javax.servlet` to `jakarta.servlet` |

> **Important — if your college lab machine uses Tomcat 9 or older:**
> Tomcat 9 (and earlier) uses the `javax.servlet.*` package instead of
> `jakarta.servlet.*`. If your lab environment only has Tomcat 9, change:
> - every `import jakarta.servlet....` to `import javax.servlet....` in
>   `DatabaseServlet.java`, and
> - the `web.xml` header to the Servlet 4.0 schema:
>   ```xml
>   <web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee"
>            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
>            xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/javaee
>                http://xmlns.jcp.org/xml/ns/javaee/web-app_4_0.xsd"
>            version="4.0">
>   ```
> No other logic needs to change.

## 10. Project Structure
```
DatabaseServlet/
├── README.md
├── TESTING.md
├── database/
│   └── setup.sql
├── src/
│   └── main/
│       ├── java/
│       │   └── com/wad/lab/
│       │       └── DatabaseServlet.java
│       └── webapp/
│           ├── index.html
│           └── WEB-INF/
│               ├── web.xml
│               └── lib/            (place mysql-connector-j.jar here)
├── evidence/                        (real terminal/HTTP proof captured while
│                                      verifying this build — see section 22)
└── report/
    └── Lab_Report_Exercise10_DatabaseServlet.docx
```

## 11. Database Setup
Database name: `wad_database_servlet`
Table name: `employees`

> **Note on naming:** the original assignment sheet inconsistently refers to
> the table as both "Employess" and "Employees". This project uses the
> correctly spelled table name **`employees`** consistently everywhere.

### 12. SQL Commands (also in `database/setup.sql`)
```sql
CREATE DATABASE wad_database_servlet;

USE wad_database_servlet;

CREATE TABLE employees (
    id    INT PRIMARY KEY,
    age   INT,
    first VARCHAR(20),
    last  VARCHAR(20)
);

INSERT INTO employees (id, age, first, last) VALUES
    (101, 20, 'Zara',  'Ali'),
    (102, 22, 'John',  'Smith'),
    (103, 21, 'Anita', 'Kumar'),
    (104, 23, 'Rahul', 'Sharma');

SELECT * FROM employees;
```

## 13. JDBC Configuration
`DatabaseServlet.java` defines three constants near the top of the class:

```java
private static final String DB_URL =
    "jdbc:mysql://localhost:3306/wad_database_servlet?useSSL=false&serverTimezone=UTC";
private static final String DB_USERNAME = "wad_user";      // <-- DB_USERNAME
private static final String DB_PASSWORD = "CHANGE_ME";     // <-- DB_PASSWORD
```

Replace `DB_PASSWORD` with the password you set for `wad_user` (created in
`setup.sql`) — or with your own MySQL account — before deploying locally.
**Never commit a real production password.**

## 14. MySQL Connector/J Setup
Two supported approaches (do not use both at once — that causes duplicate
driver registration warnings):

**Traditional (classic Tomcat deployment):**
Place `mysql-connector-j-<version>.jar` in `<TOMCAT_HOME>/lib/`. It becomes
available to every web application deployed on that Tomcat instance.

**Per-application (WAR / `WEB-INF/lib`):**
Place the same jar in `WEB-INF/lib/` inside the deployed application. This is
the more portable option since the driver travels with the WAR.

Download the driver from the official MySQL site: `https://dev.mysql.com/downloads/connector/j/`
(select the "Platform Independent" ZIP/TAR, which contains the driver JAR).

## 15. Servlet Explanation (`DatabaseServlet.java`)
- `doGet(HttpServletRequest, HttpServletResponse)` handles the GET request
  sent by `index.html`.
- `Class.forName(JDBC_DRIVER)` loads the MySQL JDBC driver class.
- `DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)` opens the
  connection.
- A `PreparedStatement` executes `SELECT id, age, first, last FROM employees
  ORDER BY id`.
- The `ResultSet` is iterated row by row and rendered into an HTML `<table>`.
- All JDBC resources (`ResultSet`, `Statement`, `Connection`) are closed in
  a `finally` block via a small `closeQuietly()` helper, in reverse order of
  creation.
- `SQLException` is caught and converted into a friendly "Unable to connect
  to the database" HTML page — the real exception is only logged
  server-side (`e.printStackTrace()`), never shown to the browser, so no
  credentials are ever exposed to the client.

## 16. web.xml Explanation
`WEB-INF/web.xml` declares the servlet and maps it explicitly:
```xml
<servlet>
    <servlet-name>DatabaseServlet</servlet-name>
    <servlet-class>com.wad.lab.DatabaseServlet</servlet-class>
</servlet>
<servlet-mapping>
    <servlet-name>DatabaseServlet</servlet-name>
    <url-pattern>/DatabaseServlet</url-pattern>
</servlet-mapping>
```
This is the traditional, framework-free way of wiring a URL pattern to a
servlet class, as required by the assignment (no `@WebServlet` annotation is
used, to avoid any ambiguity about which mechanism is doing the mapping).

## 17. GET Request Explanation
`index.html` contains:
```html
<form action="DatabaseServlet" method="get">
    <input type="submit" value="Display Employee Records">
</form>
```
Because `method="get"`, clicking the submit button makes the browser issue
an HTTP GET request to `DatabaseServlet` (resolved relative to the page's
own URL), which Tomcat routes — via the mapping in `web.xml` — to
`DatabaseServlet.doGet()`.

## 18. Tomcat Deployment
1. Build/copy the application into `<TOMCAT_HOME>/webapps/DatabaseServlet/`
   (or produce a `DatabaseServlet.war` and drop it into `webapps/` — Tomcat
   will auto-explode it).
2. Ensure the compiled `DatabaseServlet.class` is under
   `WEB-INF/classes/com/wad/lab/` and the JDBC driver jar is under
   `WEB-INF/lib/` (or in Tomcat's own `lib/`).
3. Start Tomcat:
   - Linux: `$CATALINA_HOME/bin/startup.sh`
   - Windows: `%CATALINA_HOME%\bin\startup.bat`
4. Stop Tomcat:
   - Linux: `$CATALINA_HOME/bin/shutdown.sh`
   - Windows: `%CATALINA_HOME%\bin\shutdown.bat`

## 19. Application URL
- Form page: `http://localhost:8080/DatabaseServlet/`
- Servlet endpoint (after clicking submit): `http://localhost:8080/DatabaseServlet/DatabaseServlet`

## 20. How to Run (Step by Step)
1. Install MySQL, create the database using `database/setup.sql`.
2. Install Apache Tomcat (9 with `javax.servlet`, or 10+ with
   `jakarta.servlet` — see section 9 for the exact code differences).
3. Compile `DatabaseServlet.java` against the servlet API jar that ships
   with your Tomcat version, placing the resulting `.class` file under
   `WEB-INF/classes/com/wad/lab/`.
4. Place the MySQL Connector/J jar in `WEB-INF/lib/` (or Tomcat's `lib/`).
5. Copy the whole `webapp` folder (containing `index.html` and `WEB-INF/`)
   into `<TOMCAT_HOME>/webapps/DatabaseServlet/`.
6. Start Tomcat and open `http://localhost:8080/DatabaseServlet/` in a
   browser.
7. Click **Display Employee Records**.

## 21. Expected Output
Opening the application shows a form titled "Database Servlet Application"
with a single button, **Display Employee Records**. Clicking it sends a GET
request to `DatabaseServlet`, which queries MySQL and renders:

| ID | Age | First Name | Last Name |
|---|---|---|---|
| 101 | 20 | Zara | Ali |
| 102 | 22 | John | Smith |
| 103 | 21 | Anita | Kumar |
| 104 | 23 | Rahul | Sharma |

This exact output was reproduced and verified live — see section 22.

## 22. Verification / Environment Notes (read this before grading)
This project was actually built, compiled, deployed, and exercised end to
end in a sandboxed Linux environment, **not just written and assumed to
work**. What was genuinely done:

- Installed OpenJDK 21, MySQL 8.0, and Apache Tomcat 10 and created the real
  `wad_database_servlet` database with the sample rows.
- Compiled `DatabaseServlet.java` with `javac` against the real Jakarta
  Servlet API jar — **zero errors**.
- Deployed the compiled servlet, `index.html`, and `web.xml` into a live
  Tomcat 10 instance.
- Sent real HTTP requests with `curl` to both `http://localhost:8080/DatabaseServlet/`
  and `http://localhost:8080/DatabaseServlet/DatabaseServlet` and received
  HTTP 200 responses containing the actual employee rows pulled live from
  MySQL.
- Stopped MySQL mid-test and confirmed the servlet returns a friendly error
  page with **no password or connection string leaked**, then restarted
  MySQL and confirmed normal operation resumed.
- The raw evidence (terminal output and the literal HTML responses returned
  by the running server) is saved under `evidence/` and rendered as images
  under `evidence/screenshots/` for the lab report.

**One honest limitation:** the sandbox used to build and verify this project
has an outbound network allow-list that includes package registries
(`apt`, `npm`, `pip`, `crates.io`) but **not** Maven Central or
`dev.mysql.com`, so the actual MySQL Connector/J jar could not be downloaded
there. For the live verification run only, a functionally equivalent JDBC
driver (**MariaDB Connector/J**, which also implements `jdbc:mysql://` URLs
and the MySQL wire protocol) was substituted in a throw-away copy of the
servlet, purely to prove the GET → servlet → JDBC → MySQL → HTML pipeline
executes correctly. **The delivered `DatabaseServlet.java` in this project is
unmodified and still targets `com.mysql.cj.jdbc.Driver` (official MySQL
Connector/J)**, as the assignment requires. On a normal internet-connected
machine, simply download the real MySQL Connector/J jar from
`https://dev.mysql.com/downloads/connector/j/` and place it in `WEB-INF/lib/`
— no code changes are needed.

Similarly, this sandbox has no graphical browser, so the "screenshots" in
the lab report are: (a) real HTML pages actually returned by the live Tomcat
server, rendered to an image with a headless HTML renderer, and (b) real
terminal transcripts of the commands and their actual output. Nothing was
fabricated or staged — every value shown (the 4 employee rows, the HTTP 200
statuses, the compiler output, the Tomcat log lines) came from the actual
run described above.

## 23. Troubleshooting
| Problem | Likely Cause | Fix |
|---|---|---|
| `HTTP Status 404` on `/DatabaseServlet/DatabaseServlet` | `web.xml` mapping wrong, or app not deployed under that context path | Check `<url-pattern>` matches exactly `/DatabaseServlet`; confirm the app folder name in `webapps/` |
| "Unable to connect to the database" page | MySQL not running, wrong URL/credentials, or driver jar missing | Start MySQL (`service mysql start` / `mysqld`), verify `DB_URL`/`DB_USERNAME`/`DB_PASSWORD`, confirm jar is in `WEB-INF/lib` or Tomcat `lib` |
| `ClassNotFoundException: com.mysql.cj.jdbc.Driver` | Connector/J jar missing from classpath | Add the jar to `WEB-INF/lib/` (or Tomcat `lib/`) and restart Tomcat |
| `NoClassDefFoundError` for `jakarta.servlet.*` at compile time | Compiling against the wrong servlet API version | Use the servlet-api jar bundled with your installed Tomcat version (`jakarta.servlet` for Tomcat 10+, `javax.servlet` for Tomcat 9-) |
| Table shows "No employee records were found" | Table exists but is empty, or `INSERT` step was skipped | Re-run the `INSERT` statements from `database/setup.sql` |
| Port 8080 already in use | Another process (or another Tomcat instance) is bound to 8080 | Stop the other process, or change `<Connector port="8080" .../>` in `server.xml` |
