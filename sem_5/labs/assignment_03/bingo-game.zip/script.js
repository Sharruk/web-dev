/* =========================================================
   BINGO GAME - script.js
   Two-player Bingo game built with vanilla JavaScript.
   Each player's 5x5 card contains numbers 1-25 exactly once,
   arranged in a random order.
   ========================================================= */

/* ---------------- Game State Variables ---------------- */

// Holds the 5x5 number layout for each player: array of 5 rows, each row an array of 5 numbers
let player1Card = [];
let player2Card = [];

// Holds the marked (true/false) state for each cell, same shape as the cards above
let player1Marked = [];
let player2Marked = [];

// Numbers that have already been called/marked this game (shared, since a
// number is marked on BOTH cards at the same time)
let usedNumbers = new Set();

// 1 = Player 1's turn, 2 = Player 2's turn
let currentPlayer = 1;

// Flags to control game flow
let gameStarted = false;
let gameOver = false;

/* ---------------- DOM Element References ---------------- */

const player1CardEl = document.getElementById('player1-card');
const player2CardEl = document.getElementById('player2-card');
const statusEl = document.getElementById('status');
const messageEl = document.getElementById('message');
const startBtn = document.getElementById('start-btn');
const resetBtn = document.getElementById('reset-btn');
const markBtn = document.getElementById('mark-btn');
const numberInput = document.getElementById('number-input');

/* =========================================================
   CARD GENERATION
   ========================================================= */

/**
 * Returns an array [1, 2, 3, ..., 25] shuffled into random order,
 * using the Fisher-Yates shuffle algorithm.
 */
function generateShuffledNumbers() {
  const numbers = [];
  for (let i = 1; i <= 25; i++) {
    numbers.push(i);
  }

  // Fisher-Yates shuffle: swap each element with a random earlier/equal one
  for (let i = numbers.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [numbers[i], numbers[j]] = [numbers[j], numbers[i]];
  }

  return numbers;
}

/**
 * Builds a 5x5 card (2D array) filled with a shuffled 1-25 sequence.
 * The flat 25-number array is sliced into 5 rows of 5.
 */
function generateCard() {
  const flatNumbers = generateShuffledNumbers();
  const card = [];

  for (let row = 0; row < 5; row++) {
    const rowNumbers = flatNumbers.slice(row * 5, row * 5 + 5);
    card.push(rowNumbers);
  }

  return card;
}

/**
 * Builds a 5x5 array of `false` values, used to track which
 * cells of a card have been marked.
 */
function generateEmptyMarkedGrid() {
  const grid = [];
  for (let row = 0; row < 5; row++) {
    grid.push([false, false, false, false, false]);
  }
  return grid;
}

/* =========================================================
   RENDERING
   ========================================================= */

/**
 * Renders a bingo card into its container element.
 * @param {number[][]} card - the 5x5 number layout
 * @param {boolean[][]} marked - the 5x5 marked-state grid
 * @param {HTMLElement} containerEl - element to render cells into
 * @param {Array<[number,number]>} winningCells - list of [row,col] pairs to highlight as a winning line
 */
function renderCard(card, marked, containerEl, winningCells = []) {
  containerEl.innerHTML = ''; // clear previous cells

  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 5; col++) {
      const cell = document.createElement('div');
      cell.classList.add('cell');
      cell.textContent = card[row][col];

      if (marked[row][col]) {
        cell.classList.add('marked');
      }

      // Check if this cell is part of the winning line
      const isWinningCell = winningCells.some(
        ([r, c]) => r === row && c === col
      );
      if (isWinningCell) {
        cell.classList.add('winning');
      }

      containerEl.appendChild(cell);
    }
  }
}

/**
 * Renders 5x5 placeholder (empty/disabled-looking) cells before the game starts.
 */
function renderPlaceholderCard(containerEl) {
  containerEl.innerHTML = '';
  for (let i = 0; i < 25; i++) {
    const cell = document.createElement('div');
    cell.classList.add('cell', 'placeholder');
    cell.textContent = '';
    containerEl.appendChild(cell);
  }
}

/* =========================================================
   STATUS / MESSAGE HELPERS
   ========================================================= */

function setStatus(text, isWinnerMessage = false) {
  statusEl.textContent = text;
  statusEl.classList.toggle('winner', isWinnerMessage);
}

function setMessage(text) {
  messageEl.textContent = text;
}

function updateTurnStatus() {
  setStatus(`Player ${currentPlayer}'s Turn`);
}

/* =========================================================
   WIN-CHECK LOGIC
   ========================================================= */

/**
 * Checks a player's marked grid for a completed row, column, or diagonal.
 * Returns an object: { won: boolean, cells: [[row,col], ...] }
 * `cells` contains the coordinates of the winning line (for highlighting).
 */
function checkWin(marked) {
  // --- Check rows ---
  for (let row = 0; row < 5; row++) {
    if (marked[row].every((cell) => cell === true)) {
      const cells = [0, 1, 2, 3, 4].map((col) => [row, col]);
      return { won: true, cells };
    }
  }

  // --- Check columns ---
  for (let col = 0; col < 5; col++) {
    let fullColumn = true;
    for (let row = 0; row < 5; row++) {
      if (!marked[row][col]) {
        fullColumn = false;
        break;
      }
    }
    if (fullColumn) {
      const cells = [0, 1, 2, 3, 4].map((row) => [row, col]);
      return { won: true, cells };
    }
  }

  // --- Check main diagonal (top-left to bottom-right) ---
  let mainDiagonalFull = true;
  for (let i = 0; i < 5; i++) {
    if (!marked[i][i]) {
      mainDiagonalFull = false;
      break;
    }
  }
  if (mainDiagonalFull) {
    const cells = [0, 1, 2, 3, 4].map((i) => [i, i]);
    return { won: true, cells };
  }

  // --- Check anti-diagonal (top-right to bottom-left) ---
  let antiDiagonalFull = true;
  for (let i = 0; i < 5; i++) {
    if (!marked[i][4 - i]) {
      antiDiagonalFull = false;
      break;
    }
  }
  if (antiDiagonalFull) {
    const cells = [0, 1, 2, 3, 4].map((i) => [i, 4 - i]);
    return { won: true, cells };
  }

  // No winning line found
  return { won: false, cells: [] };
}

/* =========================================================
   GAME FLOW: START / RESET
   ========================================================= */

function startGame() {
  // Generate fresh randomized cards for both players
  player1Card = generateCard();
  player2Card = generateCard();

  // Reset marked grids
  player1Marked = generateEmptyMarkedGrid();
  player2Marked = generateEmptyMarkedGrid();

  // Reset tracking state
  usedNumbers = new Set();
  currentPlayer = 1;
  gameStarted = true;
  gameOver = false;

  // Render the freshly generated cards
  renderCard(player1Card, player1Marked, player1CardEl);
  renderCard(player2Card, player2Marked, player2CardEl);

  // Update UI controls
  startBtn.disabled = true;
  markBtn.disabled = false;
  numberInput.disabled = false;
  numberInput.value = '';
  numberInput.focus();

  setMessage('');
  updateTurnStatus();
}

function resetGame() {
  // Clear game state
  player1Card = [];
  player2Card = [];
  player1Marked = [];
  player2Marked = [];
  usedNumbers = new Set();
  currentPlayer = 1;
  gameStarted = false;
  gameOver = false;

  // Show empty placeholder cards again
  renderPlaceholderCard(player1CardEl);
  renderPlaceholderCard(player2CardEl);

  // Reset controls to initial state
  startBtn.disabled = false;
  markBtn.disabled = true;
  numberInput.disabled = true;
  numberInput.value = '';

  setMessage('');
  setStatus('Click "Start" to begin the game.');
}

/* =========================================================
   MARKING LOGIC
   ========================================================= */

/**
 * Finds the [row, col] position of a given number on a card.
 * Since each card contains 1-25 exactly once, this always succeeds
 * for a valid number after the game has started.
 */
function findPosition(card, number) {
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 5; col++) {
      if (card[row][col] === number) {
        return [row, col];
      }
    }
  }
  return null;
}

function switchTurn() {
  currentPlayer = currentPlayer === 1 ? 2 : 1;
}

function handleMark() {
  // 1. Game must have started
  if (!gameStarted) {
    setMessage('Please start the game first.');
    return;
  }

  // 2. Game must not already be over
  if (gameOver) {
    setMessage('Game is over. Press Reset to play again.');
    return;
  }

  const rawValue = numberInput.value.trim();

  // 3. Input must not be empty
  if (rawValue === '') {
    setMessage('Please enter a number.');
    return;
  }

  const number = Number(rawValue);

  // 4. Input must be a valid number
  if (Number.isNaN(number) || !Number.isInteger(number)) {
    setMessage('Please enter a valid number.');
    return;
  }

  // 5. Input must be within range 1-25
  if (number < 1 || number > 25) {
    setMessage('Enter a number between 1 and 25.');
    return;
  }

  // 6. Number must not already be marked
  if (usedNumbers.has(number)) {
    setMessage('Number already marked.');
    return;
  }

  // ---- Valid number: mark it on BOTH cards ----
  usedNumbers.add(number);

  const pos1 = findPosition(player1Card, number);
  const pos2 = findPosition(player2Card, number);

  if (pos1) {
    player1Marked[pos1[0]][pos1[1]] = true;
  }
  if (pos2) {
    player2Marked[pos2[0]][pos2[1]] = true;
  }

  setMessage('');

  // ---- Check for a winner on either card ----
  const p1Result = checkWin(player1Marked);
  const p2Result = checkWin(player2Marked);

  if (p1Result.won || p2Result.won) {
    gameOver = true;

    // Render final board states with winning line highlighted
    renderCard(player1Card, player1Marked, player1CardEl, p1Result.won ? p1Result.cells : []);
    renderCard(player2Card, player2Marked, player2CardEl, p2Result.won ? p2Result.cells : []);

    // Announce winner(s). In the rare case both complete a line on the
    // same move, both are announced.
    if (p1Result.won && p2Result.won) {
      setStatus('Player 1 and Player 2 both got BINGO! It\'s a tie!', true);
    } else if (p1Result.won) {
      setStatus('Player 1 Wins! BINGO!', true);
    } else {
      setStatus('Player 2 Wins! BINGO!', true);
    }

    // Lock the game
    markBtn.disabled = true;
    numberInput.disabled = true;
    setMessage('Press Reset to start a new game.');
    return;
  }

  // ---- No winner yet: re-render boards and switch turn ----
  renderCard(player1Card, player1Marked, player1CardEl);
  renderCard(player2Card, player2Marked, player2CardEl);

  switchTurn();
  updateTurnStatus();

  numberInput.value = '';
  numberInput.focus();
}

/* =========================================================
   EVENT LISTENERS
   ========================================================= */

startBtn.addEventListener('click', startGame);
resetBtn.addEventListener('click', resetGame);
markBtn.addEventListener('click', handleMark);

// Allow pressing Enter in the input field to trigger Mark
numberInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    handleMark();
  }
});

/* =========================================================
   INITIAL PAGE STATE
   ========================================================= */

// Show empty placeholder cards on page load, before Start is clicked
renderPlaceholderCard(player1CardEl);
renderPlaceholderCard(player2CardEl);
