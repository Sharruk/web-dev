# College Symposium Management System Using Vue.js

**Exercise 6 — Web Application Development Lab (ICS1511)**

| | |
|---|---|
| **Student Name** | Sharruk S |
| **Register Number** | 3122247001061 |
| **Year / Semester** | III Year / V Semester |
| **Batch** | 2024–2029 |

## Project Description

A Vue.js 3 single-page application that helps students browse and register for
events at a 3-day college technical symposium ("Tech Vista '26"). Students can
search and filter events by category, view full event details, and register
through a validated form. Seat counts, availability, and event status update
automatically as registrations come in.

## Technologies Used

- Vue.js 3 (Composition API, `<script setup>`)
- Vite (build tool / dev server)
- Plain JavaScript, HTML, CSS
- No backend — all data lives in component state (`App.vue`)

## Features

- Browse 8 sample symposium events across 4 categories (Technical, Cultural,
  Workshop, Competition)
- Search events live by name
- Filter events by category
- View full details of any event
- Register for an event through a validated form
- Registered count, available seats, and status update automatically
- Category-based card styling and seat-based dynamic title sizing

## Component Structure

```
src/
├── main.js
├── App.vue                # Root component — owns all event data
└── components/
    ├── Header.vue          # Symposium title/subtitle (normal CSS)
    ├── EventList.vue       # Renders EventCard for each filtered event
    ├── EventCard.vue       # One event's summary (scoped CSS)
    ├── EventDetails.vue    # Full details of the selected event
    ├── RegistrationForm.vue# Registration form + validation
    └── Footer.vue           # Static footer
```

**Component communication flow**

```
App.vue
  │  props: filteredEvents
  ▼
EventList.vue
  │  props: event
  ▼
EventCard.vue  ──emit('view-details')──▶ EventList.vue ──▶ App.vue

App.vue
  │  props: selectedEvent
  ▼
EventDetails.vue
  │
  ▼
RegistrationForm.vue ──emit('submit-registration')──▶ EventDetails.vue ──emit('register')──▶ App.vue
```

## Vue Concepts Demonstrated

- **Props** — `App.vue` → `EventList.vue` → `EventCard.vue` (event data flows
  down); `App.vue` → `EventDetails.vue` (selected event)
- **`v-for`** — rendering the event card grid in `EventList.vue`
- **`v-if` / `v-else-if` / `v-else`** — showing "Registration Open" /
  "Almost Full" / "Registration Closed" in `EventCard.vue` and
  `EventDetails.vue`
- **Computed properties** — `filteredEvents` (category + search),
  `selectedEvent`, `availableSeats`, `categoryClass`, `titleFontSize`
- **`:class`** — category-based card border colors in `EventCard.vue`
- **`:style`** — dynamic event-title font size based on available seats
- **Event handling** — `@input` on the search box, `@click` on category
  buttons and the View Details / Register buttons, `@submit.prevent` on the
  registration form
- **Component communication** — props flow data down; `emits`
  (`view-details`, `register`, `submit-registration`, `close`, `cancel`)
  send events back up
- **Form validation** — `RegistrationForm.vue` checks that all four fields
  are filled before emitting `submit-registration`

## Installation Steps

```bash
npm install
```

## How to Run

```bash
npm run dev
```

Then open the printed local URL (typically `http://localhost:5173`) in a
browser.

To build a production bundle:

```bash
npm run build
```

## Sample Usage

1. On load, all 8 events are shown as cards.
2. Type "code" in the search box → only "Code Sprint" remains.
3. Click the **Workshop** filter button → only workshop events remain.
4. Click **View Details** on any open event → full details appear below the
   list, with a **Register** button (only if seats remain and registration
   is open).
5. Click **Register** → the registration form appears.
6. Submit the form empty → a validation message appears.
7. Fill in all four fields and submit → registered participants increases by
   one, available seats decrease, and a success message is shown. If seats
   hit 0 the status automatically becomes "Registration Closed" and the
   Register button disappears; if seats drop to 10 or fewer it becomes
   "Almost Full".

## Expected Application Behavior

- Available seats are **always** calculated as
  `maxParticipants - registeredParticipants` — never stored separately.
- Event status is derived automatically: `Registration Closed` when seats
  reach 0, `Almost Full` when seats are 10 or fewer, otherwise
  `Registration Open`.
- Adding a new event only requires adding a new object to the `events` array
  in `App.vue` — no component code needs to change.
