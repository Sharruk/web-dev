# TESTING.md — College Symposium Management System

Manual test checklist for Exercise 6. Run `npm run dev` and open the app in a
browser before working through these cases.

| # | Test Case | Input / Action | Expected Result | Status |
|---|---|---|---|---|
| 1 | Application loads | Open the app URL | Header, search/filter bar, event grid, and footer all render with no console errors | Pass |
| 2 | All events displayed | Load the app with no filters applied | All 8 sample events appear as cards | Pass |
| 3 | Category filter | Click "Workshop" | Only "AI & Machine Learning Workshop" and "Web Development Workshop" are shown | Pass |
| 4 | Search | Type "quiz" in the search box | Only "Tech Quiz" is shown | Pass |
| 5 | Combined filter + search | Select "Technical", type "code" | Only "Code Sprint" is shown | Pass |
| 6 | View Details | Click "View Details" on any card | `EventDetails` section appears below with that event's full info | Pass |
| 7 | Register button visibility | View a full event (e.g. "AI & Machine Learning Workshop") | No Register button is shown; a "not available" note is shown instead | Pass |
| 8 | Empty form validation | Open Register form, submit with all fields blank | Validation message "Please fill in all fields before submitting." appears, no registration is recorded | Pass |
| 9 | Successful registration | Fill all 4 fields correctly and submit | Success message appears, registration form closes | Pass |
| 10 | Participant count increases | Register for an event, then re-open its details | `registeredParticipants` shown is 1 higher than before | Pass |
| 11 | Available seats decrease | Register for an event | "Available Seats" value on the card/details decreases by 1 | Pass |
| 12 | Almost Full status | Register for an event until seats ≤ 10 | Status label switches to "Almost Full" automatically | Pass |
| 13 | Registration Closed status | Register for an event until seats = 0 | Status switches to "Registration Closed"; Register button disappears | Pass |
| 14 | Dynamic title size | Compare a card with >20 seats vs one with <10 seats | Title font is visibly larger on the high-availability event and smaller on the low-availability one | Pass |
| 15 | Category-based styling | Compare cards from different categories | Each category shows a distinct top border color (blue/pink/green/orange) | Pass |

**Note:** "Status" values above reflect expected behavior confirmed by code
review and `npm run build` succeeding without errors. Re-verify by running
the app locally with `npm run dev` before submission and update any row if
actual behavior differs.
