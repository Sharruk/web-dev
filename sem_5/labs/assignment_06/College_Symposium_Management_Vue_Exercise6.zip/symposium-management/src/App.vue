<template>
  <div class="app">
    <!-- Header.vue: uses normal (non-scoped) CSS -->
    <Header />

    <main class="main-content">
      <!-- Search and filter controls -->
      <section class="controls">
        <input
          type="text"
          class="search-box"
          placeholder="Search events by name..."
          v-model="searchText"
          @input="onSearch"
        />

        <div class="category-buttons">
          <button
            v-for="cat in categories"
            :key="cat"
            :class="{ active: selectedCategory === cat }"
            @click="onCategorySelect(cat)"
          >
            {{ cat }}
          </button>
        </div>
      </section>

      <!-- EventList.vue receives the FILTERED events as a prop -->
      <EventList
        :events="filteredEvents"
        @view-details="onViewDetails"
      />

      <!-- EventDetails.vue receives the selected event as a prop -->
      <EventDetails
        v-if="selectedEvent"
        :key="selectedEvent.eventId"
        :event="selectedEvent"
        @close="selectedEvent = null"
        @register="onRegister"
      />
    </main>

    <Footer />
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import Header from './components/Header.vue'
import EventList from './components/EventList.vue'
import EventDetails from './components/EventDetails.vue'
import Footer from './components/Footer.vue'

// ---------------------------------------------------------
// EVENT DATA - the single source of truth for the whole app.
// Adding a new event only requires adding an object here.
// ---------------------------------------------------------
const events = ref([
  {
    eventId: 1,
    eventName: 'Code Sprint',
    category: 'Technical',
    date: 'Day 1 - 10 Mar 2026',
    venue: 'Computer Lab 1',
    registrationFee: 100,
    maxParticipants: 60,
    registeredParticipants: 15,
    status: 'Registration Open'
  },
  {
    eventId: 2,
    eventName: 'Paper Presentation',
    category: 'Technical',
    date: 'Day 1 - 10 Mar 2026',
    venue: 'Seminar Hall A',
    registrationFee: 50,
    maxParticipants: 40,
    registeredParticipants: 32,
    status: 'Almost Full'
  },
  {
    eventId: 3,
    eventName: 'AI & Machine Learning Workshop',
    category: 'Workshop',
    date: 'Day 1 - 10 Mar 2026',
    venue: 'AI Lab',
    registrationFee: 150,
    maxParticipants: 50,
    registeredParticipants: 50,
    status: 'Registration Closed'
  },
  {
    eventId: 4,
    eventName: 'Tech Quiz',
    category: 'Technical',
    date: 'Day 2 - 11 Mar 2026',
    venue: 'Main Auditorium',
    registrationFee: 30,
    maxParticipants: 30,
    registeredParticipants: 12,
    status: 'Registration Open'
  },
  {
    eventId: 5,
    eventName: 'Robotics Challenge',
    category: 'Competition',
    date: 'Day 2 - 11 Mar 2026',
    venue: 'Robotics Lab',
    registrationFee: 200,
    maxParticipants: 25,
    registeredParticipants: 25,
    status: 'Registration Closed'
  },
  {
    eventId: 6,
    eventName: 'Web Development Workshop',
    category: 'Workshop',
    date: 'Day 2 - 11 Mar 2026',
    venue: 'Computer Lab 2',
    registrationFee: 120,
    maxParticipants: 40,
    registeredParticipants: 10,
    status: 'Registration Open'
  },
  {
    eventId: 7,
    eventName: 'Battle of Bands',
    category: 'Cultural',
    date: 'Day 3 - 12 Mar 2026',
    venue: 'Open Air Theatre',
    registrationFee: 0,
    maxParticipants: 100,
    registeredParticipants: 92,
    status: 'Almost Full'
  },
  {
    eventId: 8,
    eventName: 'Photography Contest',
    category: 'Competition',
    date: 'Day 3 - 12 Mar 2026',
    venue: 'Campus Grounds',
    registrationFee: 40,
    maxParticipants: 35,
    registeredParticipants: 20,
    status: 'Registration Open'
  }
])

// Category filter options
const categories = ['All Events', 'Technical', 'Cultural', 'Workshop', 'Competition']
const selectedCategory = ref('All Events')
const searchText = ref('')
const selectedEventId = ref(null)

// --- COMPUTED PROPERTIES ---

// Filters events by category AND search text together
const filteredEvents = computed(() => {
  return events.value.filter((event) => {
    const matchesCategory =
      selectedCategory.value === 'All Events' || event.category === selectedCategory.value
    const matchesSearch = event.eventName
      .toLowerCase()
      .includes(searchText.value.toLowerCase())
    return matchesCategory && matchesSearch
  })
})

// The full event object for whichever event id is currently selected
const selectedEvent = computed(() => {
  if (selectedEventId.value === null) return null
  return events.value.find((e) => e.eventId === selectedEventId.value) || null
})

// --- EVENT HANDLERS ---

function onSearch() {
  // searchText is already bound via v-model; this exists to
  // demonstrate explicit @input event handling.
}

function onCategorySelect(cat) {
  selectedCategory.value = cat
}

function onViewDetails(eventId) {
  selectedEventId.value = eventId
}

// Called when RegistrationForm -> EventDetails emits a successful registration
function onRegister({ eventId, student }) {
  const event = events.value.find((e) => e.eventId === eventId)
  if (!event) return

  // Increase registered participants, which automatically
  // recalculates available seats everywhere (computed values).
  event.registeredParticipants += 1

  const availableSeats = event.maxParticipants - event.registeredParticipants

  // Automatically update status based on the new seat count
  if (availableSeats <= 0) {
    event.status = 'Registration Closed'
  } else if (availableSeats <= 10) {
    event.status = 'Almost Full'
  } else {
    event.status = 'Registration Open'
  }

  console.log('New registration:', student, 'for event', event.eventName)
}
</script>

<style>
/* Global layout styles (kept simple, not scoped to any single component) */
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: 'Segoe UI', Arial, sans-serif;
  background: #f3f4f6;
  color: #1f2937;
}

.main-content {
  max-width: 1100px;
  margin: 0 auto;
  padding: 24px 20px;
}

.controls {
  display: flex;
  flex-wrap: wrap;
  gap: 14px;
  align-items: center;
  margin-bottom: 10px;
}

.search-box {
  flex: 1;
  min-width: 220px;
  padding: 10px 14px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 0.95rem;
}

.category-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.category-buttons button {
  padding: 8px 14px;
  border: 1px solid #d1d5db;
  background: #fff;
  border-radius: 20px;
  cursor: pointer;
  font-size: 0.85rem;
  color: #374151;
}

.category-buttons button:hover {
  background: #eef2ff;
}

.category-buttons button.active {
  background: #4f46e5;
  color: #fff;
  border-color: #4f46e5;
}
</style>
