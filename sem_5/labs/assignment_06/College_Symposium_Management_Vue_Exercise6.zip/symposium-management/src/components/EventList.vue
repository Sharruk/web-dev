<template>
  <div class="event-list">
    <!-- v-for renders one EventCard per event in the filtered list -->
    <EventCard
      v-for="event in events"
      :key="event.eventId"
      :event="event"
      @view-details="$emit('view-details', $event)"
    />

    <!-- Shown when search/filter produces no matches -->
    <p v-if="events.length === 0" class="no-results">
      No events match your search/filter.
    </p>
  </div>
</template>

<script setup>
import EventCard from './EventCard.vue'

// Props: EventList receives the already-filtered event array from App.vue
defineProps({
  events: {
    type: Array,
    required: true
  }
})

// Re-emit the view-details event up to App.vue
defineEmits(['view-details'])
</script>

<style scoped>
.event-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 20px;
  margin: 20px 0;
}

.no-results {
  grid-column: 1 / -1;
  text-align: center;
  color: #6b7280;
  padding: 30px 0;
}
</style>
