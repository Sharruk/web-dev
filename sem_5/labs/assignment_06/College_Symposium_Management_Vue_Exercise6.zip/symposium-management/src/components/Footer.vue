<template>
  <footer class="app-footer">
    <p>&copy; 2026 Tech Vista Symposium | Web Application Development Lab - Exercise 6</p>
  </footer>
</template>

<script setup>
// Static footer, no props or logic needed.
</script>

<style scoped>
.app-footer {
  text-align: center;
  padding: 16px;
  background: #1f2937;
  color: #d1d5db;
  font-size: 0.85rem;
  margin-top: 30px;
}
</style>
