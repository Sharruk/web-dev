<template>
  <!-- :class dynamically applies a category-specific class -->
  <div class="event-card" :class="categoryClass">
    <!-- :style dynamically changes the title font size based on available seats -->
    <h3 class="event-title" :style="{ fontSize: titleFontSize }">
      {{ event.eventName }}
    </h3>

    <p class="event-category">{{ event.category }}</p>

    <ul class="event-info">
      <li><strong>Date:</strong> {{ event.date }}</li>
      <li><strong>Venue:</strong> {{ event.venue }}</li>
      <li><strong>Fee:</strong> ₹{{ event.registrationFee }}</li>
      <li><strong>Available Seats:</strong> {{ availableSeats }}</li>
    </ul>

    <!-- v-if / v-else-if / v-else to show the correct status -->
    <p v-if="event.status === 'Registration Closed'" class="status status-closed">
      Registration Closed
    </p>
    <p v-else-if="event.status === 'Almost Full'" class="status status-almost">
      Almost Full
    </p>
    <p v-else class="status status-open">
      Registration Open
    </p>

    <!-- @click event handling: tell the parent which event was selected -->
    <button class="view-btn" @click="$emit('view-details', event.eventId)">
      View Details
    </button>
  </div>
</template>

<script setup>
import { computed } from 'vue'

// Props: EventCard receives a single event object from EventList.vue
const props = defineProps({
  event: {
    type: Object,
    required: true
  }
})

// Emits: tells the parent (via EventList -> App) which event was clicked
defineEmits(['view-details'])

// Available seats = maxParticipants - registeredParticipants (computed, not stored)
const availableSeats = computed(() => {
  return props.event.maxParticipants - props.event.registeredParticipants
})

// Dynamic class based on category (technical / cultural / workshop / competition)
const categoryClass = computed(() => {
  return props.event.category.toLowerCase()
})

// Dynamic font size based on available seats
const titleFontSize = computed(() => {
  const seats = availableSeats.value
  if (seats > 20) return '1.4rem'
  if (seats >= 10) return '1.1rem'
  return '0.9rem'
})
</script>

<!-- Scoped CSS: these rules apply ONLY to EventCard.vue -->
<style scoped>
.event-card {
  background: #ffffff;
  border-radius: 10px;
  padding: 18px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
  border-top: 5px solid #ccc;
  display: flex;
  flex-direction: column;
  gap: 8px;
  transition: transform 0.15s ease;
}

.event-card:hover {
  transform: translateY(-4px);
}

.event-title {
  margin: 0;
  color: #1f2937;
}

.event-category {
  margin: 0;
  font-size: 0.8rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #6b7280;
}

.event-info {
  list-style: none;
  padding: 0;
  margin: 8px 0;
  font-size: 0.9rem;
  color: #374151;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.status {
  font-weight: 600;
  margin: 4px 0;
  font-size: 0.85rem;
}

.status-open {
  color: #16a34a;
}

.status-almost {
  color: #d97706;
}

.status-closed {
  color: #dc2626;
}

.view-btn {
  margin-top: auto;
  background: #4f46e5;
  color: #fff;
  border: none;
  padding: 10px 14px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.9rem;
}

.view-btn:hover {
  background: #4338ca;
}

/* Category-based border colors, applied via :class */
.technical {
  border-top-color: #2563eb;
}

.cultural {
  border-top-color: #db2777;
}

.workshop {
  border-top-color: #16a34a;
}

.competition {
  border-top-color: #ea580c;
}
</style>
