<template>
  <div class="event-details">
    <button class="close-btn" @click="$emit('close')">✕ Close</button>

    <h2>{{ event.eventName }}</h2>
    <span class="badge" :class="event.category.toLowerCase()">{{ event.category }}</span>

    <table class="details-table">
      <tbody>
        <tr><td>Event ID</td><td>{{ event.eventId }}</td></tr>
        <tr><td>Date</td><td>{{ event.date }}</td></tr>
        <tr><td>Venue</td><td>{{ event.venue }}</td></tr>
        <tr><td>Registration Fee</td><td>₹{{ event.registrationFee }}</td></tr>
        <tr><td>Maximum Participants</td><td>{{ event.maxParticipants }}</td></tr>
        <tr><td>Registered Participants</td><td>{{ event.registeredParticipants }}</td></tr>
        <tr><td>Available Seats</td><td>{{ availableSeats }}</td></tr>
        <tr>
          <td>Status</td>
          <td>
            <span v-if="event.status === 'Registration Closed'" class="status status-closed">Registration Closed</span>
            <span v-else-if="event.status === 'Almost Full'" class="status status-almost">Almost Full</span>
            <span v-else class="status status-open">Registration Open</span>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Register button only shows if registration is open AND seats are available -->
    <button
      v-if="event.status !== 'Registration Closed' && availableSeats > 0 && !showForm"
      class="register-btn"
      @click="showForm = true"
    >
      Register for this Event
    </button>
    <p v-else-if="!showForm" class="closed-note">
      Registration is not available for this event.
    </p>

    <!-- RegistrationForm.vue only appears once the student clicks Register -->
    <RegistrationForm
      v-if="showForm"
      @submit-registration="handleRegistration"
      @cancel="showForm = false"
    />

    <p v-if="successMessage" class="success-message">{{ successMessage }}</p>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import RegistrationForm from './RegistrationForm.vue'

// Props: EventDetails receives the currently selected event as an object
const props = defineProps({
  event: {
    type: Object,
    required: true
  }
})

// Emits: 'close' goes back to the list, 'register' tells App.vue to update the event
const emit = defineEmits(['close', 'register'])

const showForm = ref(false)
const successMessage = ref('')

const availableSeats = computed(() => {
  return props.event.maxParticipants - props.event.registeredParticipants
})

// Called when RegistrationForm.vue emits a valid, filled-out form
function handleRegistration(formData) {
  // Pass the event id + form data up to App.vue, which owns the event data
  emit('register', { eventId: props.event.eventId, student: formData })
  showForm.value = false
  successMessage.value = `Registration successful! Welcome, ${formData.name}.`
}
</script>

<style scoped>
.event-details {
  background: #ffffff;
  border-radius: 10px;
  padding: 24px;
  margin: 20px 0;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.12);
  position: relative;
}

.close-btn {
  position: absolute;
  top: 16px;
  right: 16px;
  background: none;
  border: none;
  cursor: pointer;
  font-size: 0.9rem;
  color: #6b7280;
}

.badge {
  display: inline-block;
  padding: 4px 10px;
  border-radius: 20px;
  color: #fff;
  font-size: 0.8rem;
  margin-bottom: 16px;
}

.badge.technical { background: #2563eb; }
.badge.cultural { background: #db2777; }
.badge.workshop { background: #16a34a; }
.badge.competition { background: #ea580c; }

.details-table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
}

.details-table td {
  padding: 8px 6px;
  border-bottom: 1px solid #e5e7eb;
}

.details-table td:first-child {
  font-weight: 600;
  color: #374151;
  width: 45%;
}

.status-open { color: #16a34a; font-weight: 600; }
.status-almost { color: #d97706; font-weight: 600; }
.status-closed { color: #dc2626; font-weight: 600; }

.register-btn {
  background: #16a34a;
  color: #fff;
  border: none;
  padding: 12px 18px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 1rem;
}

.register-btn:hover {
  background: #15803d;
}

.closed-note {
  color: #dc2626;
  font-weight: 500;
}

.success-message {
  margin-top: 16px;
  background: #dcfce7;
  color: #166534;
  padding: 10px 14px;
  border-radius: 6px;
  font-weight: 500;
}
</style>
