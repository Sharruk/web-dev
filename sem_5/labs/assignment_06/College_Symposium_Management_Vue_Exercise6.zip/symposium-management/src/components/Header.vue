<template>
  <header class="app-header">
    <h1>Tech Vista '26 - College Symposium</h1>
    <p class="subtitle">A 3-Day Technical &amp; Cultural Symposium | Explore. Compete. Celebrate.</p>
  </header>
</template>

<script setup>
// Header.vue is a simple presentational component.
// It does not receive any props because the title/subtitle are static.
</script>

<!--
  NOTE: This is NORMAL (non-scoped) CSS, as required by the assignment.
  Because it is not scoped, these rules apply globally to the whole app.
-->
<style>
.app-header {
  background: linear-gradient(135deg, #4f46e5, #7c3aed);
  color: #ffffff;
  padding: 32px 20px;
  text-align: center;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.app-header h1 {
  margin: 0 0 8px 0;
  font-size: 2rem;
  letter-spacing: 0.5px;
}

.app-header .subtitle {
  margin: 0;
  font-size: 1rem;
  opacity: 0.9;
}
</style>
