<template>
  <!-- @submit.prevent stops the page from reloading on form submit -->
  <form class="registration-form" @submit.prevent="handleSubmit">
    <h3>Registration Form</h3>

    <div class="form-group">
      <label for="name">Student Name</label>
      <input id="name" v-model="name" type="text" placeholder="Enter your full name" />
    </div>

    <div class="form-group">
      <label for="regNo">Register Number</label>
      <input id="regNo" v-model="registerNumber" type="text" placeholder="Enter your register number" />
    </div>

    <div class="form-group">
      <label for="email">Email</label>
      <input id="email" v-model="email" type="email" placeholder="Enter your email" />
    </div>

    <div class="form-group">
      <label for="dept">Department</label>
      <input id="dept" v-model="department" type="text" placeholder="Enter your department" />
    </div>

    <!-- Validation message shown when required fields are missing -->
    <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>

    <div class="form-actions">
      <button type="submit" class="submit-btn">Submit Registration</button>
      <button type="button" class="cancel-btn" @click="$emit('cancel')">Cancel</button>
    </div>
  </form>
</template>

<script setup>
import { ref } from 'vue'

const emit = defineEmits(['submit-registration', 'cancel'])

const name = ref('')
const registerNumber = ref('')
const email = ref('')
const department = ref('')
const errorMessage = ref('')

function handleSubmit() {
  // Validate that all fields are filled before allowing registration
  if (!name.value.trim() || !registerNumber.value.trim() || !email.value.trim() || !department.value.trim()) {
    errorMessage.value = 'Please fill in all fields before submitting.'
    return
  }

  errorMessage.value = ''

  // Send the filled-out form data up to EventDetails.vue
  emit('submit-registration', {
    name: name.value.trim(),
    registerNumber: registerNumber.value.trim(),
    email: email.value.trim(),
    department: department.value.trim()
  })
}
</script>

<style scoped>
.registration-form {
  background: #f9fafb;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 20px;
  margin-top: 16px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.registration-form h3 {
  margin: 0 0 6px 0;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.form-group label {
  font-size: 0.85rem;
  font-weight: 600;
  color: #374151;
}

.form-group input {
  padding: 8px 10px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 0.9rem;
}

.error-message {
  color: #dc2626;
  font-size: 0.85rem;
  margin: 0;
}

.form-actions {
  display: flex;
  gap: 10px;
  margin-top: 8px;
}

.submit-btn {
  background: #4f46e5;
  color: #fff;
  border: none;
  padding: 10px 16px;
  border-radius: 6px;
  cursor: pointer;
}

.submit-btn:hover {
  background: #4338ca;
}

.cancel-btn {
  background: #e5e7eb;
  color: #374151;
  border: none;
  padding: 10px 16px;
  border-radius: 6px;
  cursor: pointer;
}

.cancel-btn:hover {
  background: #d1d5db;
}
</style>
